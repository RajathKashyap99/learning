import { createContext, useContext, useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: string;
  name: string;
  email: string;
  profileImage?: string;
  location?: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => void;
  register: (name: string, email: string, password: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data
const MOCK_USER: User = {
  id: '1',
  name: 'Cyndy Lillibridge',
  email: 'cyndy@example.com',
  profileImage: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
  location: 'Torrance, CA, United States',
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Simulate checking if user is already logged in
    const checkAuth = async () => {
      setLoading(true);
      try {
        // In a real app, this would check for a token in localStorage
        // and verify it with the backend
        
        // For demo purposes, just set a mock user after a delay
        setTimeout(() => {
          setUser(MOCK_USER);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Auth check failed:', error);
        setUser(null);
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      // In a real app, this would call an API endpoint
      // For demo purposes, just set the mock user
      
      // Simulate API delay
      setTimeout(() => {
        setUser(MOCK_USER);
        toast({
          title: 'Logged in',
          description: 'Welcome back!',
        });
      }, 500);
    } catch (error) {
      console.error('Login failed:', error);
      toast({
        title: 'Login failed',
        description: 'Invalid email or password.',
        variant: 'destructive',
      });
    }
  };

  const register = async (name: string, email: string, password: string) => {
    try {
      // In a real app, this would call an API endpoint
      // For demo purposes, create a new user based on the mock

      // Simulate API delay
      setTimeout(() => {
        const newUser = {
          ...MOCK_USER,
          id: `user-${Date.now()}`,
          name,
          email,
        };
        setUser(newUser);
        toast({
          title: 'Registration successful',
          description: 'Your account has been created.',
        });
      }, 500);
    } catch (error) {
      console.error('Registration failed:', error);
      toast({
        title: 'Registration failed',
        description: 'Could not create your account.',
        variant: 'destructive',
      });
    }
  };

  const logout = () => {
    // In a real app, this would clear tokens, etc.
    setUser(null);
    toast({
      title: 'Logged out',
      description: 'You have been logged out.',
    });
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}