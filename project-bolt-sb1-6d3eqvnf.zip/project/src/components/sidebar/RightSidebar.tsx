import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { UserPlus } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface FriendRequestProps {
  name: string;
  imageUrl: string;
  message: string;
}

interface SuggestionProps {
  name: string;
  location: string;
  imageUrl: string;
}

const FriendRequest = ({ name, imageUrl, message }: FriendRequestProps) => (
  <div className="flex items-start mb-4">
    <Avatar className="h-10 w-10 mr-3 mt-1">
      <AvatarImage src={imageUrl} alt={name} />
      <AvatarFallback>{name.charAt(0)}</AvatarFallback>
    </Avatar>
    <div className="flex-1">
      <p className="text-sm">
        <span className="font-semibold">{name}</span> {message}
      </p>
      <div className="flex gap-2 mt-2">
        <Button size="sm" variant="default" className="h-8">Accept</Button>
        <Button size="sm" variant="outline" className="h-8">Decline</Button>
      </div>
    </div>
  </div>
);

const UserSuggestion = ({ name, location, imageUrl }: SuggestionProps) => (
  <div className="flex items-center mb-4">
    <Avatar className="h-10 w-10 mr-3">
      <AvatarImage src={imageUrl} alt={name} />
      <AvatarFallback>{name.charAt(0)}</AvatarFallback>
    </Avatar>
    <div className="flex-1 min-w-0">
      <p className="text-sm font-medium truncate">{name}</p>
      <p className="text-xs text-muted-foreground truncate">{location}</p>
    </div>
    <Button variant="outline" size="icon" className="h-8 w-8">
      <UserPlus className="h-4 w-4" />
    </Button>
  </div>
);

export default function RightSidebar() {
  return (
    <ScrollArea className="h-full py-6 px-4">
      {/* Friend Requests Section */}
      <div className="mb-6">
        <h3 className="font-semibold mb-4 flex items-center">
          Requests <span className="ml-2 bg-primary text-primary-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center">2</span>
        </h3>
        
        <FriendRequest 
          name="Lauralee Quintero" 
          imageUrl="https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg"
          message="wants to add you to friends"
        />
        
        <FriendRequest 
          name="Brittni Landoma" 
          imageUrl="https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg"
          message="wants to add you to friends"
        />
      </div>
      
      <Separator className="my-6" />
      
      {/* Suggestions Section */}
      <div className="mb-6">
        <h3 className="font-semibold mb-4">Suggestions for you</h3>
        
        <UserSuggestion 
          name="Chantal Shelburne" 
          location="Memphis, TN, US" 
          imageUrl="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg"
        />
        
        <UserSuggestion 
          name="Marci Senter" 
          location="Newark, NJ, US" 
          imageUrl="https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg"
        />
        
        <UserSuggestion 
          name="Janetta Rotolo" 
          location="Fort Worth, TX, US" 
          imageUrl="https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg"
        />
        
        <UserSuggestion 
          name="Tyra Dhillon" 
          location="Springfield, MA, US" 
          imageUrl="https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg"
        />
        
        <UserSuggestion 
          name="Marielle Wigington" 
          location="Honolulu, HI, US" 
          imageUrl="https://images.pexels.com/photos/1520760/pexels-photo-1520760.jpeg"
        />
        
        <div className="text-center mt-4">
          <Button variant="link" size="sm">
            View All
          </Button>
        </div>
      </div>
      
      <Separator className="my-6" />
      
      {/* Followers Section */}
      <div className="mb-6">
        <div className="flex justify-center mb-3">
          <div className="flex -space-x-2">
            {[
              "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg",
              "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg",
              "https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg",
              "https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg",
              "https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg",
              "https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg",
              "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg"
            ].map((url, index) => (
              <Avatar key={index} className="border-2 border-background h-8 w-8">
                <AvatarImage src={url} />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            ))}
          </div>
        </div>
        
        <p className="text-center font-semibold text-lg">184.3K</p>
        <p className="text-center text-sm text-muted-foreground">Followers</p>
        <p className="text-center text-xs mt-1 text-muted-foreground">Active now on your profile</p>
      </div>
      
      <Separator className="my-6" />
      
      {/* Footer Links */}
      <div className="text-xs text-muted-foreground">
        <div className="flex flex-wrap gap-x-4 gap-y-2 mb-3">
          <a href="#" className="hover:underline">About</a>
          <a href="#" className="hover:underline">Accessibility</a>
          <a href="#" className="hover:underline">Help Center</a>
          <a href="#" className="hover:underline">Privacy and Terms</a>
          <a href="#" className="hover:underline">Advertising</a>
        </div>
        <div>
          <a href="#" className="hover:underline">Business Services</a>
        </div>
      </div>
    </ScrollArea>
  );
}