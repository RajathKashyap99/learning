import { Home, Compass, Bookmark, MessageSquare, BarChart2, Settings, Search, PlusCircle } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';
import { useState } from 'react';
import CreatePostModal from '../post/CreatePostModal';

const NavItem = ({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) => (
  <Button 
    variant={active ? "secondary" : "ghost"} 
    className="w-full justify-start mb-1 font-normal"
  >
    <div className="flex items-center">
      <div className="mr-3">{icon}</div>
      {label}
    </div>
  </Button>
);

const ContactItem = ({ name, location, avatarUrl }: { name: string; location: string; avatarUrl: string }) => (
  <div className="flex items-center mb-4">
    <Avatar className="h-10 w-10 mr-3">
      <AvatarImage src={avatarUrl} alt={name} />
      <AvatarFallback>{name.charAt(0)}</AvatarFallback>
    </Avatar>
    <div className="flex-1 min-w-0">
      <p className="text-sm font-medium truncate">{name}</p>
      <p className="text-xs text-muted-foreground truncate">{location}</p>
    </div>
    <Button variant="ghost" size="icon" className="h-8 w-8">
      <MessageSquare className="h-4 w-4" />
    </Button>
  </div>
);

export default function Sidebar() {
  const { user } = useAuth();
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);

  return (
    <div className="flex flex-col h-full bg-background border-r border-border">
      <ScrollArea className="flex-1 px-3">
        {/* User profile */}
        <div className="pt-6 pb-4 px-2">
          <div className="flex items-center mb-4">
            <Avatar className="h-14 w-14 mr-3">
              <AvatarImage src={user?.profileImage || "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg"} alt={user?.name || "User"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold">{user?.name || "Cyndy Lillibridge"}</h3>
              <p className="text-xs text-muted-foreground">{user?.location || "Torrance, CA, United States"}</p>
            </div>
          </div>
          
          <div className="flex justify-between mb-4 text-center">
            <div className="flex-1">
              <p className="font-semibold">368</p>
              <p className="text-xs text-muted-foreground">Posts</p>
            </div>
            <div className="flex-1">
              <p className="font-semibold">184.3K</p>
              <p className="text-xs text-muted-foreground">Followers</p>
            </div>
            <div className="flex-1">
              <p className="font-semibold">1.04M</p>
              <p className="text-xs text-muted-foreground">Following</p>
            </div>
          </div>
        </div>
        
        <Separator />
        
        {/* Search and create post */}
        <div className="py-4 px-2">
          <div className="relative mb-4">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search..." className="pl-8" />
          </div>
          
          <Button 
            className="w-full mb-4 gap-2" 
            onClick={() => setIsCreatePostOpen(true)}
          >
            <PlusCircle className="h-4 w-4" />
            Create new post
          </Button>
        </div>
        
        {/* Navigation */}
        <div className="px-2 py-2">
          <NavItem icon={<Home className="h-5 w-5" />} label="Feed" active />
          <NavItem icon={<Compass className="h-5 w-5" />} label="Explore" />
          <NavItem icon={<Bookmark className="h-5 w-5" />} label="My favorites" />
          <NavItem icon={<MessageSquare className="h-5 w-5" />} label="Direct" />
          <NavItem icon={<BarChart2 className="h-5 w-5" />} label="Stats" />
          <NavItem icon={<Settings className="h-5 w-5" />} label="Settings" />
        </div>
        
        <Separator className="my-4" />
        
        {/* Contacts section */}
        <div className="px-2 py-2">
          <h3 className="font-semibold mb-4">Contacts</h3>
          
          <ContactItem 
            name="Julie Mendez" 
            location="Memphis, TN, US" 
            avatarUrl="https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg" 
          />
          
          <ContactItem 
            name="Marian Montgomery" 
            location="Newark, NJ, US" 
            avatarUrl="https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg" 
          />
          
          <ContactItem 
            name="Joyce Reid" 
            location="Fort Worth, TX, US" 
            avatarUrl="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg" 
          />
          
          <ContactItem 
            name="Alice Franklin" 
            location="Springfield, MA, US" 
            avatarUrl="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg" 
          />
          
          <ContactItem 
            name="Domingo Flores" 
            location="Honolulu, HI, US" 
            avatarUrl="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg" 
          />
          
          <div className="text-center mt-4">
            <Button variant="link" size="sm">
              View All
            </Button>
          </div>
        </div>
      </ScrollArea>

      <CreatePostModal open={isCreatePostOpen} onOpenChange={setIsCreatePostOpen} />
    </div>
  );
}