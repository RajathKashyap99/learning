import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Heart, MessageCircle, Share2, BookmarkIcon, MoreHorizontal } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { formatDistanceToNow } from "date-fns";
import CommentSection from "./CommentSection";

interface PostUser {
  id: string;
  name: string;
  username: string;
  avatar: string;
}

interface Post {
  id: string;
  user: PostUser;
  content: string;
  images: string[];
  hashtags: string[];
  likes: number;
  comments: number;
  createdAt: string;
}

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [isFullPostOpen, setIsFullPostOpen] = useState(false);

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1);
    } else {
      setLikeCount(likeCount + 1);
    }
    setLiked(!liked);
  };

  const handleSave = () => {
    setSaved(!saved);
  };

  return (
    <>
      <Card className="border border-border shadow-sm">
        <CardHeader className="p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <Avatar>
                <AvatarImage src={post.user.avatar} alt={post.user.name} />
                <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">{post.user.name}</div>
                <div className="text-sm text-muted-foreground">@{post.user.username}</div>
              </div>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsFullPostOpen(true)}>View post</DropdownMenuItem>
                <DropdownMenuItem>Copy link</DropdownMenuItem>
                <DropdownMenuItem>Share to...</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">Report post</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          {post.images.length > 0 && (
            <div className="relative">
              {post.images.length === 1 ? (
                <img 
                  src={post.images[0]} 
                  alt="Post content" 
                  className="w-full h-auto object-cover max-h-[500px]"
                  onClick={() => setIsFullPostOpen(true)}
                />
              ) : (
                <Carousel>
                  <CarouselContent>
                    {post.images.map((image, index) => (
                      <CarouselItem key={index}>
                        <img 
                          src={image} 
                          alt={`Post content ${index + 1}`} 
                          className="w-full h-auto object-cover max-h-[500px]"
                          onClick={() => setIsFullPostOpen(true)}
                        />
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <CarouselPrevious />
                  <CarouselNext />
                </Carousel>
              )}
            </div>
          )}
          
          <div className="p-4">
            <p className="mb-2">{post.content}</p>
            {post.hashtags.length > 0 && (
              <div className="flex flex-wrap gap-1 mb-2">
                {post.hashtags.map((tag, index) => (
                  <span key={index} className="text-blue-600 dark:text-blue-400 text-sm">
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="px-4 py-3 border-t border-border flex justify-between">
          <div className="flex space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLike}
              className={liked ? "text-red-500" : ""}
            >
              <Heart className={`h-5 w-5 mr-1 ${liked ? "fill-current" : ""}`} />
              {likeCount > 1000 ? `${(likeCount / 1000).toFixed(1)}k` : likeCount}
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsCommentsOpen(true)}
            >
              <MessageCircle className="h-5 w-5 mr-1" />
              {post.comments > 1000 ? `${(post.comments / 1000).toFixed(1)}k` : post.comments}
            </Button>
            
            <Button variant="ghost" size="sm">
              <Share2 className="h-5 w-5 mr-1" />
            </Button>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className={saved ? "text-primary" : ""}
            onClick={handleSave}
          >
            <BookmarkIcon className={`h-5 w-5 ${saved ? "fill-primary" : ""}`} />
          </Button>
        </CardFooter>
      </Card>

      {/* Comments Dialog */}
      <Dialog open={isCommentsOpen} onOpenChange={setIsCommentsOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Comments</DialogTitle>
            <DialogDescription>
              Join the conversation about this post.
            </DialogDescription>
          </DialogHeader>
          <CommentSection postId={post.id} />
        </DialogContent>
      </Dialog>

      {/* Full Post Dialog */}
      <Dialog open={isFullPostOpen} onOpenChange={setIsFullPostOpen}>
        <DialogContent className="sm:max-w-[800px] p-0 overflow-hidden">
          <div className="flex flex-col md:flex-row h-full">
            {/* Image section */}
            <div className="w-full md:w-1/2 bg-black">
              <Carousel className="h-full">
                <CarouselContent className="h-full">
                  {post.images.map((image, index) => (
                    <CarouselItem key={index} className="h-full">
                      <div className="flex items-center justify-center h-full">
                        <img 
                          src={image} 
                          alt={`Post content ${index + 1}`} 
                          className="max-h-[600px] max-w-full object-contain"
                        />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious />
                <CarouselNext />
              </Carousel>
            </div>
            
            {/* Content section */}
            <div className="w-full md:w-1/2 flex flex-col h-full">
              {/* Header */}
              <div className="p-4 border-b flex items-center space-x-3">
                <Avatar>
                  <AvatarImage src={post.user.avatar} alt={post.user.name} />
                  <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{post.user.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                  </div>
                </div>
              </div>
              
              {/* Post content */}
              <div className="p-4">
                <p className="mb-2">{post.content}</p>
                {post.hashtags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {post.hashtags.map((tag, index) => (
                      <span key={index} className="text-blue-600 dark:text-blue-400 text-sm">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Comments */}
              <div className="flex-1 overflow-auto border-t">
                <CommentSection postId={post.id} />
              </div>
              
              {/* Action buttons */}
              <div className="p-3 border-t flex justify-between">
                <div className="flex space-x-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleLike}
                    className={liked ? "text-red-500" : ""}
                  >
                    <Heart className={`h-5 w-5 mr-1 ${liked ? "fill-current" : ""}`} />
                    {likeCount}
                  </Button>
                  
                  <Button variant="ghost" size="sm">
                    <Share2 className="h-5 w-5 mr-1" />
                    Share
                  </Button>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className={saved ? "text-primary" : ""}
                  onClick={handleSave}
                >
                  <BookmarkIcon className={`h-5 w-5 ${saved ? "fill-primary" : ""}`} />
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}