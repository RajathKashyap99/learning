import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Image, X } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface CreatePostModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function CreatePostModal({ open, onOpenChange }: CreatePostModalProps) {
  const [postContent, setPostContent] = useState("");
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [imageURLs, setImageURLs] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        setSelectedImages(prev => [...prev, ...files]);
        
        // Create object URLs for preview
        const newImageURLs = files.map(file => URL.createObjectURL(file));
        setImageURLs(prev => [...prev, ...newImageURLs]);
      }
    }
  };

  const removeImage = (index: number) => {
    const newSelectedImages = [...selectedImages];
    const newImageURLs = [...imageURLs];
    
    // Revoke the object URL to prevent memory leaks
    URL.revokeObjectURL(newImageURLs[index]);
    
    newSelectedImages.splice(index, 1);
    newImageURLs.splice(index, 1);
    
    setSelectedImages(newSelectedImages);
    setImageURLs(newImageURLs);
  };

  const handleCreatePost = () => {
    // This would normally call an API to create a post
    // For now, just show a toast
    toast({
      title: "Post created",
      description: "Your post was successfully created!"
    });
    
    // Clean up form and image previews
    setPostContent("");
    imageURLs.forEach(url => URL.revokeObjectURL(url));
    setSelectedImages([]);
    setImageURLs([]);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create new post</DialogTitle>
        </DialogHeader>
        
        <div className="flex items-center space-x-3 mb-4">
          <Avatar>
            <AvatarImage 
              src={user?.profileImage || "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg"} 
              alt={user?.name || "User"} 
            />
            <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{user?.name || "Cyndy Lillibridge"}</p>
          </div>
        </div>
        
        <Tabs defaultValue="post">
          <TabsList className="mb-4">
            <TabsTrigger value="post">Post</TabsTrigger>
            <TabsTrigger value="story">Story</TabsTrigger>
          </TabsList>
          
          <TabsContent value="post" className="space-y-4">
            <Textarea 
              placeholder="What's on your mind?" 
              className="min-h-[120px]"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
            />
            
            {imageURLs.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {imageURLs.map((url, index) => (
                  <div key={index} className="relative rounded-md overflow-hidden h-32">
                    <img 
                      src={url} 
                      alt={`Preview ${index}`} 
                      className="w-full h-full object-cover"
                    />
                    <Button 
                      variant="destructive" 
                      size="icon" 
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={() => removeImage(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
            
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                onClick={() => fileInputRef.current?.click()}
              >
                <Image className="h-4 w-4 mr-2" />
                Add Images
              </Button>
              <input 
                type="file" 
                ref={fileInputRef} 
                style={{ display: "none" }} 
                accept="image/*" 
                multiple 
                onChange={handleImageSelect}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="story" className="space-y-4">
            <div className="text-center p-8 border border-dashed rounded-md">
              <p className="text-muted-foreground">Story creation is coming soon!</p>
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="flex justify-end mt-4">
          <Button 
            variant="outline" 
            className="mr-2"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleCreatePost}
            disabled={!postContent.trim() && imageURLs.length === 0}
          >
            Create post
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}