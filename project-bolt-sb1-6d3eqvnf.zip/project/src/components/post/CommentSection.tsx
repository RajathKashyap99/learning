import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, MoreHorizontal } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/context/AuthContext";

interface CommentSectionProps {
  postId: string;
}

// Sample comment data
const SAMPLE_COMMENTS = [
  {
    id: "1",
    postId: "1",
    user: {
      id: "201",
      name: "Sarah Johnson",
      avatar: "https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg"
    },
    content: "This is absolutely breathtaking! Where exactly in Florina was this taken?",
    likes: 24,
    createdAt: "2023-09-15T15:30:00.000Z"
  },
  {
    id: "2",
    postId: "1",
    user: {
      id: "202",
      name: "Michael Chen",
      avatar: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg"
    },
    content: "The light in these photos is incredible. What time of day did you shoot these?",
    likes: 15,
    createdAt: "2023-09-15T16:42:00.000Z"
  },
  {
    id: "3",
    postId: "1",
    user: {
      id: "203",
      name: "Emma Wilson",
      avatar: "https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg"
    },
    content: "I've been wanting to visit Greece for so long. These photos just convinced me to book my trip!",
    likes: 37,
    createdAt: "2023-09-15T18:15:00.000Z"
  },
];

export default function CommentSection({ postId }: CommentSectionProps) {
  const [comments, setComments] = useState(SAMPLE_COMMENTS.filter(comment => comment.postId === postId));
  const [newComment, setNewComment] = useState("");
  const { user } = useAuth();

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    
    const newCommentObj = {
      id: `temp-${Date.now()}`,
      postId,
      user: {
        id: user?.id || "temp-user",
        name: user?.name || "Current User",
        avatar: user?.profileImage || "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg"
      },
      content: newComment,
      likes: 0,
      createdAt: new Date().toISOString()
    };
    
    setComments([...comments, newCommentObj]);
    setNewComment("");
  };

  const handleLikeComment = (commentId: string) => {
    setComments(comments.map(comment => {
      if (comment.id === commentId) {
        return {
          ...comment,
          likes: comment.likes + 1
        };
      }
      return comment;
    }));
  };

  const handleDeleteComment = (commentId: string) => {
    setComments(comments.filter(comment => comment.id !== commentId));
  };

  return (
    <div className="flex flex-col h-full">
      <ScrollArea className="flex-1 p-4">
        {comments.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center text-muted-foreground">
            <p>No comments yet</p>
            <p className="text-sm">Be the first to share your thoughts!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {comments.map(comment => (
              <div key={comment.id} className="flex space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={comment.user.avatar} alt={comment.user.name} />
                  <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="bg-accent rounded-lg p-3">
                    <div className="flex justify-between items-start">
                      <span className="font-medium">{comment.user.name}</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleDeleteComment(comment.id)}>
                            Delete
                          </DropdownMenuItem>
                          <DropdownMenuItem>Report</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <p className="text-sm mt-1">{comment.content}</p>
                  </div>
                  <div className="flex items-center mt-1 text-xs text-muted-foreground">
                    <span>{formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-xs ml-1" onClick={() => handleLikeComment(comment.id)}>
                      {comment.likes > 0 && comment.likes} Like
                    </Button>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">Reply</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
      
      <div className="p-4 border-t">
        <div className="flex space-x-2">
          <Avatar className="h-8 w-8">
            <AvatarImage 
              src={user?.profileImage || "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg"} 
              alt={user?.name || "You"} 
            />
            <AvatarFallback>{user?.name?.charAt(0) || "Y"}</AvatarFallback>
          </Avatar>
          <div className="flex-1 flex">
            <Input 
              placeholder="Add a comment..." 
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleAddComment();
                }
              }}
              className="flex-1"
            />
            <Button 
              variant="ghost" 
              onClick={handleAddComment}
              disabled={!newComment.trim()}
              className="ml-2"
            >
              Post
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}