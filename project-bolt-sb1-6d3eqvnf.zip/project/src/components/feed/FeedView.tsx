import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PostCard from "../post/PostCard";
import StoriesSection from "./StoriesSection";
import { useEffect, useState } from "react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import { Button } from "../ui/button";
import { PlusCircle } from "lucide-react";
import CreatePostModal from "../post/CreatePostModal";
import { ScrollArea } from "../ui/scroll-area";

// Sample data for posts
const SAMPLE_POSTS = [
  {
    id: "1",
    user: {
      id: "101",
      name: "Robert Fox",
      username: "classicmovernews",
      avatar: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg"
    },
    content: "While Corfu give us the ability to shoot by the sea with amazing blue background full of light of the sky, Florina give us its gentle side. The humble atmosphere and Light of Florina which comes...",
    images: [
      "https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg",
      "https://images.pexels.com/photos/346529/pexels-photo-346529.jpeg",
      "https://images.pexels.com/photos/691668/pexels-photo-691668.jpeg",
      "https://images.pexels.com/photos/167699/pexels-photo-167699.jpeg",
    ],
    hashtags: ["landscape", "flora", "nature"],
    likes: 1600,
    comments: 2300,
    createdAt: "2023-09-15T14:48:00.000Z"
  },
  {
    id: "2",
    user: {
      id: "102",
      name: "Dianne Russell",
      username: "amandadasilva",
      avatar: "https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg"
    },
    content: "Exploring the vibrant streets of Tokyo at night. The neon lights create such an amazing atmosphere!",
    images: [
      "https://images.pexels.com/photos/2506923/pexels-photo-2506923.jpeg",
    ],
    hashtags: ["travel", "tokyo", "nightlife"],
    likes: 2400,
    comments: 320,
    createdAt: "2023-09-14T10:24:00.000Z"
  },
  {
    id: "3",
    user: {
      id: "103",
      name: "Cameron Williamson",
      username: "cameronw",
      avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
    },
    content: "Just finished this digital art piece after weeks of work. What do you think?",
    images: [
      "https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg",
    ],
    hashtags: ["digitalart", "illustration", "artwork"],
    likes: 3500,
    comments: 540,
    createdAt: "2023-09-13T16:12:00.000Z"
  }
];

export default function FeedView() {
  const [posts, setPosts] = useState(SAMPLE_POSTS);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const isMobile = useMediaQuery("(max-width: 768px)");

  useEffect(() => {
    // This would be a good place to fetch posts from the API
    // For now, we're using sample data
  }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold">Stories</h1>
        {isMobile && (
          <Button 
            onClick={() => setIsCreatePostOpen(true)} 
            className="gap-1"
          >
            <PlusCircle className="h-4 w-4" />
            Create
          </Button>
        )}
      </div>
      
      {/* Stories section */}
      <StoriesSection />
      
      <h1 className="text-xl font-bold mt-8 mb-4">Feeds</h1>
      
      {/* Feed tabs */}
      <Tabs defaultValue="popular" className="mb-8">
        <TabsList className="grid w-full max-w-[400px] grid-cols-2">
          <TabsTrigger value="popular">Popular</TabsTrigger>
          <TabsTrigger value="latest">Latest</TabsTrigger>
        </TabsList>
        
        <TabsContent value="popular" className="mt-6 space-y-6">
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </TabsContent>
        
        <TabsContent value="latest" className="mt-6 space-y-6">
          {[...posts].reverse().map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </TabsContent>
      </Tabs>

      <CreatePostModal open={isCreatePostOpen} onOpenChange={setIsCreatePostOpen} />
    </div>
  );
}