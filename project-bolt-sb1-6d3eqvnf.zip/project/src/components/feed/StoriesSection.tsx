import { PlusIcon } from "lucide-react";
import { ScrollArea } from "../ui/scroll-area";

// Sample data for stories
const STORIES = [
  { id: "1", username: "Add story", isUser: true, avatar: "" },
  { id: "2", username: "Robert", avatar: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg" },
  { id: "3", username: "Jessica", avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg" },
  { id: "4", username: "Cameron", avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg" },
  { id: "5", username: "Sarah", avatar: "https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg" },
  { id: "6", username: "Jacob", avatar: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg" },
  { id: "7", username: "Emma", avatar: "https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg" },
  { id: "8", username: "Michael", avatar: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg" },
];

interface StoryCircleProps {
  avatar: string;
  username: string;
  isUser?: boolean;
}

const StoryCircle = ({ avatar, username, isUser = false }: StoryCircleProps) => {
  return (
    <div className="flex flex-col items-center space-y-1 px-2">
      <div className={`relative group cursor-pointer rounded-full ${isUser ? 'border-dashed border-2 border-primary/80' : 'border-2 border-transparent bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 p-[3px]'}`}>
        <div className={`w-16 h-16 rounded-full overflow-hidden flex items-center justify-center ${isUser ? 'bg-muted' : 'bg-background'}`}>
          {isUser ? (
            <PlusIcon className="h-8 w-8 text-primary/80" />
          ) : (
            <img 
              src={avatar} 
              alt={username} 
              className="w-full h-full object-cover"
            />
          )}
        </div>
      </div>
      <span className="text-xs truncate max-w-[70px] text-center">{username}</span>
    </div>
  );
};

export default function StoriesSection() {
  return (
    <ScrollArea className="w-full">
      <div className="flex space-x-2 pb-4">
        {STORIES.map(story => (
          <StoryCircle 
            key={story.id}
            username={story.username}
            avatar={story.avatar}
            isUser={story.isUser}
          />
        ))}
      </div>
    </ScrollArea>
  );
}