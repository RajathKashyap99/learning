import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import AuthModal from "./AuthModal";
import LoadingSpinner from "../LoadingSpinner";

interface AuthWrapperProps {
  children: React.ReactNode;
}

export default function AuthWrapper({ children }: AuthWrapperProps) {
  const { user, loading } = useAuth();
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    // Check if user is authenticated after loading is complete
    if (!loading && !user) {
      setShowAuth(true);
    }
  }, [user, loading]);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <>
      {children}
      <AuthModal open={showAuth} onOpenChange={setShowAuth} />
    </>
  );
}