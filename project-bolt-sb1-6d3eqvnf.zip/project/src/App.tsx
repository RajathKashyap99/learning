import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { useState } from 'react';
import AppLayout from './layouts/AppLayout';
import { AuthProvider } from './context/AuthContext';
import AuthWrapper from './components/auth/AuthWrapper';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <ThemeProvider defaultTheme={darkMode ? 'dark' : 'light'} forcedTheme={darkMode ? 'dark' : 'light'}>
      <AuthProvider>
        <AuthWrapper>
          <AppLayout />
        </AuthWrapper>
        <Toaster />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;