// Backend code that would run on Express.js on EC2
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import { userRoutes } from './routes/userRoutes';
import { postRoutes } from './routes/postRoutes';
import { authRoutes } from './routes/authRoutes';
import { uploadRoutes } from './routes/uploadRoutes';

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/upload', uploadRoutes);

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/socialconnect')
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
  });

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;