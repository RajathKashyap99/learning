import express from 'express';
import { getPresignedUrl } from '../controllers/uploadController';
import { protect } from '../middleware/authMiddleware';

const router = express.Router();

// Protected routes
router.post('/presigned-url', protect, getPresignedUrl);

export const uploadRoutes = router;