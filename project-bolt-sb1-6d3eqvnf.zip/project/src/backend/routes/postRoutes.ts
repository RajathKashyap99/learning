import express from 'express';
import {
  createPost,
  getFeedPosts,
  getPostById,
  toggleLikePost,
  deletePost,
} from '../controllers/postController';
import {
  createComment,
  getPostComments,
  toggleLikeComment,
  deleteComment,
} from '../controllers/commentController';
import { protect } from '../middleware/authMiddleware';

const router = express.Router();

// Post routes
router.post('/', protect, createPost);
router.get('/feed', protect, getFeedPosts);
router.get('/:id', protect, getPostById);
router.post('/:id/like', protect, toggleLikePost);
router.delete('/:id', protect, deletePost);

// Comment routes
router.post('/:postId/comments', protect, createComment);
router.get('/:postId/comments', protect, getPostComments);
router.post('/comments/:id/like', protect, toggleLikeComment);
router.delete('/comments/:id', protect, deleteComment);

export const postRoutes = router;