import express from 'express';
import {
  getUserProfile,
  updateUserProfile,
  getUserPosts,
  followUser,
  unfollowUser,
  getUserSuggestions,
} from '../controllers/userController';
import { protect } from '../middleware/authMiddleware';

const router = express.Router();

// Protected routes
router.get('/profile/:id', protect, getUserProfile);
router.put('/profile', protect, updateUserProfile);
router.get('/posts/:id', protect, getUserPosts);
router.post('/follow/:id', protect, followUser);
router.post('/unfollow/:id', protect, unfollowUser);
router.get('/suggestions', protect, getUserSuggestions);

export const userRoutes = router;