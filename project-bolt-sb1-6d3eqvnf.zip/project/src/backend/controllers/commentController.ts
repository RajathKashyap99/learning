import { Request, Response } from 'express';
import Comment from '../models/Comment';
import Post from '../models/Post';

// Create a comment
export const createComment = async (req: Request, res: Response) => {
  try {
    const { content } = req.body;
    const postId = req.params.postId;
    const userId = (req as any).user.id;

    // Create new comment
    const newComment = new Comment({
      user: userId,
      post: postId,
      content,
    });

    const savedComment = await newComment.save();

    // Add comment to post's comments array
    await Post.findByIdAndUpdate(postId, {
      $push: { comments: savedComment._id },
    });

    // Populate user details
    const populatedComment = await Comment.findById(savedComment._id).populate({
      path: 'user',
      select: 'name profileImage',
    });

    res.status(201).json(populatedComment);
  } catch (error) {
    console.error('Create comment error:', error);
    res.status(500).json({ message: 'Server error during comment creation' });
  }
};

// Get all comments for a post
export const getPostComments = async (req: Request, res: Response) => {
  try {
    const postId = req.params.postId;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;

    const comments = await Comment.find({ post: postId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate({
        path: 'user',
        select: 'name profileImage',
      });

    const total = await Comment.countDocuments({ post: postId });

    res.status(200).json({
      comments,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get post comments error:', error);
    res.status(500).json({ message: 'Server error while fetching comments' });
  }
};

// Like or unlike a comment
export const toggleLikeComment = async (req: Request, res: Response) => {
  try {
    const commentId = req.params.id;
    const userId = (req as any).user.id;

    const comment = await Comment.findById(commentId);
    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }

    const isLiked = comment.likes.includes(userId);

    if (isLiked) {
      // Unlike the comment
      await Comment.findByIdAndUpdate(commentId, {
        $pull: { likes: userId },
      });
    } else {
      // Like the comment
      await Comment.findByIdAndUpdate(commentId, {
        $push: { likes: userId },
      });
    }

    const updatedComment = await Comment.findById(commentId);
    res.status(200).json({ likes: updatedComment?.likes });
  } catch (error) {
    console.error('Toggle like comment error:', error);
    res.status(500).json({ message: 'Server error while toggling like' });
  }
};

// Delete a comment
export const deleteComment = async (req: Request, res: Response) => {
  try {
    const commentId = req.params.id;
    const userId = (req as any).user.id;

    const comment = await Comment.findById(commentId);
    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }

    // Check if the user is the owner of the comment
    if (comment.user.toString() !== userId) {
      return res.status(403).json({ message: 'User not authorized to delete this comment' });
    }

    // Remove the comment from post's comments array
    await Post.findByIdAndUpdate(comment.post, {
      $pull: { comments: commentId },
    });

    // Delete the comment
    await Comment.findByIdAndDelete(commentId);

    res.status(200).json({ message: 'Comment deleted successfully' });
  } catch (error) {
    console.error('Delete comment error:', error);
    res.status(500).json({ message: 'Server error while deleting comment' });
  }
};