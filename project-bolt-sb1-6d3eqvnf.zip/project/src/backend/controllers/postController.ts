import { Request, Response } from 'express';
import Post from '../models/Post';
import User from '../models/User';
import Comment from '../models/Comment';

// Create a new post
export const createPost = async (req: Request, res: Response) => {
  try {
    const { content, images, hashtags } = req.body;
    const userId = (req as any).user.id;

    // Create new post
    const newPost = new Post({
      user: userId,
      content,
      images: images || [],
      hashtags: hashtags || [],
    });

    const savedPost = await newPost.save();

    // Add post to user's posts array
    await User.findByIdAndUpdate(userId, {
      $push: { posts: savedPost._id },
    });

    // Populate user details
    const populatedPost = await Post.findById(savedPost._id).populate({
      path: 'user',
      select: 'name profileImage',
    });

    res.status(201).json(populatedPost);
  } catch (error) {
    console.error('Create post error:', error);
    res.status(500).json({ message: 'Server error during post creation' });
  }
};

// Get all posts (feed)
export const getFeedPosts = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;

    // Get user's following list
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get posts from followed users and current user
    const posts = await Post.find({
      $or: [
        { user: { $in: user.following } },
        { user: userId },
      ],
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate({
        path: 'user',
        select: 'name profileImage',
      })
      .populate({
        path: 'comments',
        select: 'content user createdAt',
        options: { limit: 3, sort: { createdAt: -1 } },
        populate: {
          path: 'user',
          select: 'name profileImage',
        },
      });

    const total = await Post.countDocuments({
      $or: [
        { user: { $in: user.following } },
        { user: userId },
      ],
    });

    res.status(200).json({
      posts,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get feed posts error:', error);
    res.status(500).json({ message: 'Server error while fetching feed' });
  }
};

// Get single post by ID
export const getPostById = async (req: Request, res: Response) => {
  try {
    const postId = req.params.id;

    const post = await Post.findById(postId)
      .populate({
        path: 'user',
        select: 'name profileImage',
      })
      .populate({
        path: 'comments',
        select: 'content user createdAt likes',
        populate: {
          path: 'user',
          select: 'name profileImage',
        },
      });

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    res.status(200).json(post);
  } catch (error) {
    console.error('Get post by ID error:', error);
    res.status(500).json({ message: 'Server error while fetching post' });
  }
};

// Like or unlike a post
export const toggleLikePost = async (req: Request, res: Response) => {
  try {
    const postId = req.params.id;
    const userId = (req as any).user.id;

    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    const isLiked = post.likes.includes(userId);

    if (isLiked) {
      // Unlike the post
      await Post.findByIdAndUpdate(postId, {
        $pull: { likes: userId },
      });
    } else {
      // Like the post
      await Post.findByIdAndUpdate(postId, {
        $push: { likes: userId },
      });
    }

    const updatedPost = await Post.findById(postId);
    res.status(200).json({ likes: updatedPost?.likes });
  } catch (error) {
    console.error('Toggle like post error:', error);
    res.status(500).json({ message: 'Server error while toggling like' });
  }
};

// Delete a post
export const deletePost = async (req: Request, res: Response) => {
  try {
    const postId = req.params.id;
    const userId = (req as any).user.id;

    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Check if the user is the owner of the post
    if (post.user.toString() !== userId) {
      return res.status(403).json({ message: 'User not authorized to delete this post' });
    }

    // Delete all comments associated with the post
    await Comment.deleteMany({ post: postId });

    // Remove the post from user's posts array
    await User.findByIdAndUpdate(userId, {
      $pull: { posts: postId },
    });

    // Delete the post
    await Post.findByIdAndDelete(postId);

    res.status(200).json({ message: 'Post deleted successfully' });
  } catch (error) {
    console.error('Delete post error:', error);
    res.status(500).json({ message: 'Server error while deleting post' });
  }
};