import { Request, Response } from 'express';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import crypto from 'crypto';

// AWS S3 configuration
const s3Client = new S3Client({
  region: process.env.AWS_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
  },
});

const BUCKET_NAME = process.env.AWS_S3_BUCKET || 'social-connect-uploads';

// Generate presigned URL for direct upload to S3
export const getPresignedUrl = async (req: Request, res: Response) => {
  try {
    const { fileType, fileName } = req.body;
    
    if (!fileType || !fileName) {
      return res.status(400).json({ message: 'File type and name are required' });
    }
    
    // Generate a unique file name to prevent overwrites
    const randomBytes = crypto.randomBytes(16).toString('hex');
    const key = `uploads/${(req as any).user.id}/${randomBytes}-${fileName}`;
    
    // Set the appropriate content type
    const contentType = fileType;
    
    // Create command for S3 upload
    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      ContentType: contentType,
    });
    
    // Generate presigned URL (expires in 15 minutes)
    const presignedUrl = await getSignedUrl(s3Client, command, { expiresIn: 900 });
    
    res.status(200).json({
      url: presignedUrl,
      key: key,
      fileUrl: `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`,
    });
  } catch (error) {
    console.error('Presigned URL generation error:', error);
    res.status(500).json({ message: 'Error generating upload URL' });
  }
};