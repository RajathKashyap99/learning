import { Request, Response } from 'express';
import User from '../models/User';
import Post from '../models/Post';

// Get user profile
export const getUserProfile = async (req: Request, res: Response) => {
  try {
    const userId = req.params.id;
    const user = await User.findById(userId).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.status(200).json(user);
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({ message: 'Server error while fetching user profile' });
  }
};

// Update user profile
export const updateUserProfile = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const { name, bio, location, profileImage } = req.body;
    
    // Find user and update
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        $set: {
          name: name,
          bio: bio,
          location: location,
          profileImage: profileImage,
        },
      },
      { new: true }
    ).select('-password');
    
    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.status(200).json(updatedUser);
  } catch (error) {
    console.error('Update user profile error:', error);
    res.status(500).json({ message: 'Server error while updating profile' });
  }
};

// Get user posts
export const getUserPosts = async (req: Request, res: Response) => {
  try {
    const userId = req.params.id;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;
    
    const posts = await Post.find({ user: userId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate({
        path: 'user',
        select: 'name profileImage',
      });
    
    const total = await Post.countDocuments({ user: userId });
    
    res.status(200).json({
      posts,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get user posts error:', error);
    res.status(500).json({ message: 'Server error while fetching user posts' });
  }
};

// Follow a user
export const followUser = async (req: Request, res: Response) => {
  try {
    const userToFollowId = req.params.id;
    const userId = (req as any).user.id;
    
    // Check if trying to follow self
    if (userId === userToFollowId) {
      return res.status(400).json({ message: 'You cannot follow yourself' });
    }
    
    // Check if user to follow exists
    const userToFollow = await User.findById(userToFollowId);
    if (!userToFollow) {
      return res.status(404).json({ message: 'User to follow not found' });
    }
    
    // Check if already following
    const currentUser = await User.findById(userId);
    if (!currentUser) {
      return res.status(404).json({ message: 'Current user not found' });
    }
    
    if (currentUser.following.includes(userToFollowId)) {
      return res.status(400).json({ message: 'Already following this user' });
    }
    
    // Add userToFollow to current user's following list
    await User.findByIdAndUpdate(userId, {
      $push: { following: userToFollowId },
    });
    
    // Add current user to userToFollow's followers list
    await User.findByIdAndUpdate(userToFollowId, {
      $push: { followers: userId },
    });
    
    res.status(200).json({ message: 'Successfully followed user' });
  } catch (error) {
    console.error('Follow user error:', error);
    res.status(500).json({ message: 'Server error while following user' });
  }
};

// Unfollow a user
export const unfollowUser = async (req: Request, res: Response) => {
  try {
    const userToUnfollowId = req.params.id;
    const userId = (req as any).user.id;
    
    // Check if trying to unfollow self
    if (userId === userToUnfollowId) {
      return res.status(400).json({ message: 'You cannot unfollow yourself' });
    }
    
    // Check if user to unfollow exists
    const userToUnfollow = await User.findById(userToUnfollowId);
    if (!userToUnfollow) {
      return res.status(404).json({ message: 'User to unfollow not found' });
    }
    
    // Check if actually following
    const currentUser = await User.findById(userId);
    if (!currentUser) {
      return res.status(404).json({ message: 'Current user not found' });
    }
    
    if (!currentUser.following.includes(userToUnfollowId)) {
      return res.status(400).json({ message: 'Not following this user' });
    }
    
    // Remove userToUnfollow from current user's following list
    await User.findByIdAndUpdate(userId, {
      $pull: { following: userToUnfollowId },
    });
    
    // Remove current user from userToUnfollow's followers list
    await User.findByIdAndUpdate(userToUnfollowId, {
      $pull: { followers: userId },
    });
    
    res.status(200).json({ message: 'Successfully unfollowed user' });
  } catch (error) {
    console.error('Unfollow user error:', error);
    res.status(500).json({ message: 'Server error while unfollowing user' });
  }
};

// Get user suggestions
export const getUserSuggestions = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const limit = parseInt(req.query.limit as string) || 5;
    
    // Get user's following list
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Find users not followed by the current user
    const suggestions = await User.find({
      _id: { $ne: userId, $nin: user.following },
    })
      .select('name profileImage location')
      .limit(limit);
    
    res.status(200).json(suggestions);
  } catch (error) {
    console.error('Get user suggestions error:', error);
    res.status(500).json({ message: 'Server error while fetching suggestions' });
  }
};