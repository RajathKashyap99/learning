import { useState } from 'react';
import Sidebar from '@/components/sidebar/Sidebar';
import FeedView from '@/components/feed/FeedView';
import RightSidebar from '@/components/sidebar/RightSidebar';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isDesktop = useMediaQuery('(min-width: 1024px)');
  const isTablet = useMediaQuery('(min-width: 768px)');

  return (
    <div className="flex h-screen bg-background">
      {/* Mobile menu button */}
      {!isDesktop && (
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetTrigger asChild className="absolute top-4 left-4 z-50 lg:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0">
            <Sidebar />
          </SheetContent>
        </Sheet>
      )}

      {/* Desktop sidebar */}
      {isDesktop && (
        <div className="w-64 hidden lg:block">
          <Sidebar />
        </div>
      )}

      {/* Main content */}
      <ScrollArea className="flex-1 h-screen">
        <FeedView />
      </ScrollArea>

      {/* Right sidebar */}
      {isTablet && (
        <div className="w-80 hidden md:block border-l border-border">
          <RightSidebar />
        </div>
      )}
    </div>
  );
}