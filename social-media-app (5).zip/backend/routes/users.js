const express = require("express")
const router = express.Router()
const User = require("../models/User")
const Post = require("../models/Post")
const auth = require("../middleware/auth")
const multer = require("multer")
const path = require("path")
const { v4: uuidv4 } = require("uuid")

// Configure multer for profile picture uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/profiles/")
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname)
    cb(null, `profile-${uuidv4()}${ext}`)
  },
})

const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true)
  } else {
    cb(new Error("Not an image! Please upload only images."), false)
  }
}

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB
  },
})

// Get user profile by username
router.get("/:username", async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username })
      .select("-password -email -isAdmin")
      .populate("postCount")

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    // Get user's posts
    const posts = await Post.find({ user: user._id })
      .sort({ createdAt: -1 })
      .limit(10)
      .populate("user", "username displayName profilePicture")

    res.json({
      success: true,
      user: {
        ...user.toObject(),
        followers: user.followers.length,
        following: user.following.length,
        posts: user.postCount || 0,
      },
      posts,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Update user profile
router.put("/profile", auth, upload.single("profilePicture"), async (req, res) => {
  try {
    const updates = req.body
    const allowedUpdates = ["displayName", "bio", "location"]

    // Filter out invalid updates
    const validUpdates = Object.keys(updates)
      .filter((update) => allowedUpdates.includes(update))
      .reduce((obj, key) => {
        obj[key] = updates[key]
        return obj
      }, {})

    // Add profile picture if uploaded
    if (req.file) {
      validUpdates.profilePicture = `/uploads/profiles/${req.file.filename}`
    }

    const user = await User.findByIdAndUpdate(req.user.id, validUpdates, { new: true, runValidators: true }).select(
      "-password",
    )

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    res.json({
      success: true,
      user: {
        ...user.toObject(),
        followers: user.followers.length,
        following: user.following.length,
      },
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Follow a user
router.post("/:id/follow", auth, async (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({
        success: false,
        message: "You cannot follow yourself",
      })
    }

    const userToFollow = await User.findById(req.params.id)

    if (!userToFollow) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    const currentUser = await User.findById(req.user.id)

    // Check if already following
    if (currentUser.following.includes(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "You are already following this user",
      })
    }

    // Add to following
    await User.findByIdAndUpdate(req.user.id, {
      $push: { following: req.params.id },
    })

    // Add to followers
    await User.findByIdAndUpdate(req.params.id, {
      $push: { followers: req.user.id },
    })

    res.json({
      success: true,
      message: "User followed successfully",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Unfollow a user
router.delete("/:id/follow", auth, async (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({
        success: false,
        message: "You cannot unfollow yourself",
      })
    }

    const userToUnfollow = await User.findById(req.params.id)

    if (!userToUnfollow) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    const currentUser = await User.findById(req.user.id)

    // Check if not following
    if (!currentUser.following.includes(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "You are not following this user",
      })
    }

    // Remove from following
    await User.findByIdAndUpdate(req.user.id, {
      $pull: { following: req.params.id },
    })

    // Remove from followers
    await User.findByIdAndUpdate(req.params.id, {
      $pull: { followers: req.user.id },
    })

    res.json({
      success: true,
      message: "User unfollowed successfully",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get user suggestions
router.get("/suggestions", auth, async (req, res) => {
  try {
    const currentUser = await User.findById(req.user.id)

    // Get users not followed by current user
    const suggestions = await User.find({
      _id: {
        $ne: req.user.id,
        $nin: currentUser.following,
      },
    })
      .select("username displayName profilePicture location")
      .limit(5)

    res.json({
      success: true,
      suggestions,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get friend requests
router.get("/friend-requests", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate("friendRequests.from", "username displayName profilePicture")

    res.json({
      success: true,
      requests: user.friendRequests,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Accept friend request
router.post("/friend-requests/:requestId/accept", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)

    // Find the request
    const requestIndex = user.friendRequests.findIndex((req) => req._id.toString() === req.params.requestId)

    if (requestIndex === -1) {
      return res.status(404).json({
        success: false,
        message: "Friend request not found",
      })
    }

    const requesterId = user.friendRequests[requestIndex].from

    // Add to following
    await User.findByIdAndUpdate(req.user.id, {
      $push: { following: requesterId },
      $pull: { friendRequests: { _id: req.params.requestId } },
    })

    // Add to followers
    await User.findByIdAndUpdate(requesterId, {
      $push: { followers: req.user.id },
    })

    res.json({
      success: true,
      message: "Friend request accepted",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Decline friend request
router.post("/friend-requests/:requestId/decline", auth, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user.id, {
      $pull: { friendRequests: { _id: req.params.requestId } },
    })

    res.json({
      success: true,
      message: "Friend request declined",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

module.exports = router
