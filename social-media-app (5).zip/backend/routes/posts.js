const express = require("express")
const router = express.Router()
const Post = require("../models/Post")
const User = require("../models/User")
const auth = require("../middleware/auth")
const multer = require("multer")
const path = require("path")
const { v4: uuidv4 } = require("uuid")

// Configure multer for post image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/posts/")
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname)
    cb(null, `post-${uuidv4()}${ext}`)
  },
})

const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true)
  } else {
    cb(new Error("Not an image! Please upload only images."), false)
  }
}

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
})

// Create a post
router.post("/", auth, upload.array("images", 4), async (req, res) => {
  try {
    const { content } = req.body

    // Validate content or images
    if (!content && (!req.files || req.files.length === 0)) {
      return res.status(400).json({
        success: false,
        message: "Post must have content or images",
      })
    }

    // Process uploaded images
    const images = req.files ? req.files.map((file) => `/uploads/posts/${file.filename}`) : []

    // Create post
    const post = new Post({
      user: req.user.id,
      content,
      images,
    })

    await post.save()

    // Populate user data
    await post.populate("user", "username displayName profilePicture")

    res.status(201).json({
      success: true,
      post,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get feed posts
router.get("/feed", auth, async (req, res) => {
  try {
    const page = Number.parseInt(req.query.page) || 1
    const limit = Number.parseInt(req.query.limit) || 10
    const skip = (page - 1) * limit

    const user = await User.findById(req.user.id)

    // Get posts from followed users and own posts
    const posts = await Post.find({
      $or: [{ user: { $in: user.following } }, { user: req.user.id }],
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("user", "username displayName profilePicture")

    res.json({
      success: true,
      posts,
      page,
      hasMore: posts.length === limit,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get explore posts
router.get("/explore", async (req, res) => {
  try {
    const page = Number.parseInt(req.query.page) || 1
    const limit = Number.parseInt(req.query.limit) || 20
    const skip = (page - 1) * limit

    // Get popular posts based on likes
    const posts = await Post.find()
      .sort({ "likes.length": -1, createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("user", "username displayName profilePicture")

    res.json({
      success: true,
      posts,
      page,
      hasMore: posts.length === limit,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get user posts
router.get("/user/:username", async (req, res) => {
  try {
    const page = Number.parseInt(req.query.page) || 1
    const limit = Number.parseInt(req.query.limit) || 10
    const skip = (page - 1) * limit

    const user = await User.findOne({ username: req.params.username })

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    const posts = await Post.find({ user: user._id })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("user", "username displayName profilePicture")

    res.json({
      success: true,
      posts,
      page,
      hasMore: posts.length === limit,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Like a post
router.post("/:id/like", auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    // Check if already liked
    if (post.isLikedBy(req.user.id)) {
      return res.status(400).json({
        success: false,
        message: "Post already liked",
      })
    }

    // Add like
    post.likes.push(req.user.id)
    await post.save()

    res.json({
      success: true,
      message: "Post liked successfully",
      likesCount: post.likes.length,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Unlike a post
router.delete("/:id/like", auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    // Check if not liked
    if (!post.isLikedBy(req.user.id)) {
      return res.status(400).json({
        success: false,
        message: "Post not liked yet",
      })
    }

    // Remove like
    post.likes = post.likes.filter((like) => like.toString() !== req.user.id)
    await post.save()

    res.json({
      success: true,
      message: "Post unliked successfully",
      likesCount: post.likes.length,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Save a post
router.post("/:id/save", auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    const user = await User.findById(req.user.id)

    // Check if already saved
    if (user.savedPosts.includes(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Post already saved",
      })
    }

    // Add to saved posts
    user.savedPosts.push(req.params.id)
    await user.save()

    res.json({
      success: true,
      message: "Post saved successfully",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Unsave a post
router.delete("/:id/save", auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    const user = await User.findById(req.user.id)

    // Check if not saved
    if (!user.savedPosts.includes(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Post not saved yet",
      })
    }

    // Remove from saved posts
    user.savedPosts = user.savedPosts.filter((id) => id.toString() !== req.params.id)
    await user.save()

    res.json({
      success: true,
      message: "Post unsaved successfully",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get saved posts
router.get("/saved", auth, async (req, res) => {
  try {
    const page = Number.parseInt(req.query.page) || 1
    const limit = Number.parseInt(req.query.limit) || 10
    const skip = (page - 1) * limit

    const user = await User.findById(req.user.id)

    const posts = await Post.find({
      _id: { $in: user.savedPosts },
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("user", "username displayName profilePicture")

    res.json({
      success: true,
      posts,
      page,
      hasMore: posts.length === limit,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Add comment to post
router.post("/:id/comments", auth, async (req, res) => {
  try {
    const { content } = req.body

    if (!content) {
      return res.status(400).json({
        success: false,
        message: "Comment content is required",
      })
    }

    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    // Add comment
    post.comments.push({
      user: req.user.id,
      content,
    })

    await post.save()

    // Get updated post with populated comments
    const updatedPost = await Post.findById(req.params.id).populate(
      "comments.user",
      "username displayName profilePicture",
    )

    res.status(201).json({
      success: true,
      comments: updatedPost.comments,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get post comments
router.get("/:id/comments", async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate("comments.user", "username displayName profilePicture")

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    res.json({
      success: true,
      comments: post.comments,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

module.exports = router
