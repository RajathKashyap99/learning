const mongoose = require("mongoose")

const PostSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    content: {
      type: String,
      trim: true,
      maxlength: 500,
    },
    images: [
      {
        type: String,
      },
    ],
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    comments: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: true,
        },
        content: {
          type: String,
          required: true,
          trim: true,
          maxlength: 300,
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    hashtags: [
      {
        type: String,
        trim: true,
      },
    ],
  },
  {
    timestamps: true,
  },
)

// Method to check if a user has liked the post
PostSchema.methods.isLikedBy = function (userId) {
  return this.likes.some((like) => like.toString() === userId.toString())
}

// Method to extract hashtags from content
PostSchema.pre("save", function (next) {
  if (this.isModified("content")) {
    const hashtagRegex = /#[a-zA-Z0-9_]+/g
    const hashtags = this.content.match(hashtagRegex)

    if (hashtags) {
      this.hashtags = hashtags
    }
  }
  next()
})

module.exports = mongoose.model("Post", PostSchema)
