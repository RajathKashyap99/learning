import axios from "axios"

// Create an axios instance with default config
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
  headers: {
    "Content-Type": "application/json",
  },
})

// Add a request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token")
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

// Auth API
export const authAPI = {
  login: (email: string, password: string) => api.post("/auth/login", { email, password }),

  register: (userData: any) => api.post("/auth/register", userData),

  getCurrentUser: () => api.get("/auth/me"),
}

// User API
export const userAPI = {
  getProfile: (username: string) => api.get(`/users/${username}`),

  updateProfile: (userData: any) => api.put("/users/profile", userData),

  followUser: (userId: string) => api.post(`/users/${userId}/follow`),

  unfollowUser: (userId: string) => api.delete(`/users/${userId}/follow`),

  getSuggestions: () => api.get("/users/suggestions"),

  getFriendRequests: () => api.get("/users/friend-requests"),

  acceptFriendRequest: (requestId: string) => api.post(`/users/friend-requests/${requestId}/accept`),

  declineFriendRequest: (requestId: string) => api.post(`/users/friend-requests/${requestId}/decline`),
}

// Post API
export const postAPI = {
  getFeed: (page = 1, limit = 10) => api.get(`/posts/feed?page=${page}&limit=${limit}`),

  getExplore: (page = 1, limit = 20) => api.get(`/posts/explore?page=${page}&limit=${limit}`),

  getUserPosts: (username: string, page = 1, limit = 10) =>
    api.get(`/posts/user/${username}?page=${page}&limit=${limit}`),

  createPost: (postData: FormData) =>
    api.post("/posts", postData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    }),

  likePost: (postId: string) => api.post(`/posts/${postId}/like`),

  unlikePost: (postId: string) => api.delete(`/posts/${postId}/like`),

  savePost: (postId: string) => api.post(`/posts/${postId}/save`),

  unsavePost: (postId: string) => api.delete(`/posts/${postId}/save`),

  getSavedPosts: (page = 1, limit = 10) => api.get(`/posts/saved?page=${page}&limit=${limit}`),

  getPostComments: (postId: string) => api.get(`/posts/${postId}/comments`),

  addComment: (postId: string, content: string) => api.post(`/posts/${postId}/comments`, { content }),
}

export default api
