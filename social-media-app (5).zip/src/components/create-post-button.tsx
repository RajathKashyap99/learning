import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function CreatePostButton() {
  return (
    <Link to="/create-post">
      <Button className="rounded-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
        <Plus className="h-4 w-4" />
        Create new post
      </Button>
    </Link>
  )
}
