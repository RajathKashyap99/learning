"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Heart, MessageCircle, Bookmark, MoreHorizontal, Share2 } from "lucide-react"

interface PostCardProps {
  post: {
    id: string
    user: {
      id: string
      username: string
      displayName: string
      profilePicture: string
    }
    content: string
    images: string[]
    likes: number
    comments: number
    createdAt: string
    hashtags?: string[]
  }
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [saved, setSaved] = useState(false)
  const [likesCount, setLikesCount] = useState(post.likes)

  const handleLike = () => {
    if (liked) {
      setLikesCount((prev) => prev - 1)
    } else {
      setLikesCount((prev) => prev + 1)
    }
    setLiked(!liked)
    // In a real app, you would make an API call here
  }

  const handleSave = () => {
    setSaved(!saved)
    // In a real app, you would make an API call here
  }

  return (
    <Card className="border-border mb-4">
      <CardHeader className="p-4 flex flex-row items-center space-y-0">
        <Link to={`/profile/${post.user.username}`} className="flex items-center gap-2 flex-1">
          <Avatar>
            <AvatarImage src={post.user.profilePicture || "/placeholder.svg"} alt={post.user.displayName} />
            <AvatarFallback>{post.user.displayName.substring(0, 2)}</AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-medium">{post.user.displayName}</p>
            <p className="text-xs text-muted-foreground">@{post.user.username}</p>
          </div>
        </Link>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4" />
              <span className="sr-only">More options</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Report post</DropdownMenuItem>
            <DropdownMenuItem>Copy link</DropdownMenuItem>
            <DropdownMenuItem>Mute user</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="p-0">
        {post.images.length > 0 && (
          <div className={`grid ${post.images.length > 1 ? "grid-cols-2 gap-0.5" : ""}`}>
            {post.images.map((image, index) => (
              <img
                key={index}
                src={image || "/placeholder.svg"}
                alt={`Post image ${index + 1}`}
                className="w-full object-cover"
                style={{
                  aspectRatio: post.images.length === 1 ? "1" : index === 0 && post.images.length === 3 ? "2/1" : "1/1",
                }}
              />
            ))}
          </div>
        )}
        <div className="p-4">
          <p className="text-sm">{post.content}</p>
          {post.hashtags && post.hashtags.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {post.hashtags.map((tag, index) => (
                <Link
                  key={index}
                  to={`/hashtag/${tag.replace("#", "")}`}
                  className="text-xs text-primary hover:underline"
                >
                  {tag}
                </Link>
              ))}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex flex-col">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className={`h-8 w-8 ${liked ? "text-red-500" : ""}`}
              onClick={handleLike}
            >
              <Heart className="h-5 w-5 fill-current" />
              <span className="sr-only">Like</span>
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MessageCircle className="h-5 w-5" />
              <span className="sr-only">Comment</span>
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Share2 className="h-5 w-5" />
              <span className="sr-only">Share</span>
            </Button>
          </div>
          <Button variant="ghost" size="icon" className={`h-8 w-8 ${saved ? "text-primary" : ""}`} onClick={handleSave}>
            <Bookmark className={`h-5 w-5 ${saved ? "fill-current" : ""}`} />
            <span className="sr-only">Save</span>
          </Button>
        </div>
        <div className="mt-2 text-sm">
          <p className="font-medium">{likesCount.toLocaleString()} likes</p>
          <p className="text-xs text-muted-foreground mt-1">
            {new Date(post.createdAt).toLocaleDateString(undefined, {
              month: "short",
              day: "numeric",
            })}
          </p>
        </div>
      </CardFooter>
    </Card>
  )
}
