"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { UserPlus } from "lucide-react"

type FriendRequest = {
  id: string
  username: string
  displayName: string
  profilePicture: string
  message: string
}

type SuggestedUser = {
  id: string
  username: string
  displayName: string
  profilePicture: string
  location: string
}

export default function RightSidebar() {
  // Mock data for friend requests
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([
    {
      id: "1",
      username: "lauralee",
      displayName: "Lauralee Quintero",
      profilePicture: "/placeholder.svg",
      message: "wants to add you to friends",
    },
    {
      id: "2",
      username: "brittni",
      displayName: "Brittni Landoma",
      profilePicture: "/placeholder.svg",
      message: "wants to add you to friends",
    },
  ])

  // Mock data for suggested users
  const [suggestedUsers, setSuggestedUsers] = useState<SuggestedUser[]>([
    {
      id: "1",
      username: "chantal",
      displayName: "Chantal Shelburne",
      profilePicture: "/placeholder.svg",
      location: "Memphis, TN, US",
    },
    {
      id: "2",
      username: "marci",
      displayName: "Marci Senter",
      profilePicture: "/placeholder.svg",
      location: "Newark, NJ, US",
    },
    {
      id: "3",
      username: "janetta",
      displayName: "Janetta Rotolo",
      profilePicture: "/placeholder.svg",
      location: "Fort Worth, TX, US",
    },
    {
      id: "4",
      username: "tyra",
      displayName: "Tyra Dhillon",
      profilePicture: "/placeholder.svg",
      location: "Springfield, MA, US",
    },
    {
      id: "5",
      username: "marielle",
      displayName: "Marielle Wigington",
      profilePicture: "/placeholder.svg",
      location: "Honolulu, HI, US",
    },
  ])

  const handleAcceptRequest = (id: string) => {
    setFriendRequests((prev) => prev.filter((request) => request.id !== id))
    // In a real app, you would make an API call here
  }

  const handleDeclineRequest = (id: string) => {
    setFriendRequests((prev) => prev.filter((request) => request.id !== id))
    // In a real app, you would make an API call here
  }

  const handleFollow = (id: string) => {
    // In a real app, you would make an API call here
    console.log(`Following user with id: ${id}`)
  }

  return (
    <div className="w-80 p-4 hidden lg:block sticky top-0 h-screen overflow-y-auto">
      {/* Friend Requests Section */}
      {friendRequests.length > 0 && (
        <div className="mb-8">
          <h3 className="font-semibold text-lg mb-4">
            Requests{" "}
            <span className="bg-primary text-primary-foreground rounded-full px-1.5 py-0.5 text-xs ml-1">
              {friendRequests.length}
            </span>
          </h3>
          <div className="space-y-4">
            {friendRequests.map((request) => (
              <div key={request.id} className="flex items-start gap-3">
                <Avatar>
                  <AvatarImage src={request.profilePicture || "/placeholder.svg"} alt={request.displayName} />
                  <AvatarFallback>{request.displayName.substring(0, 2)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{request.displayName}</p>
                  <p className="text-xs text-muted-foreground">{request.message}</p>
                  <div className="flex gap-2 mt-2">
                    <Button
                      size="sm"
                      variant="default"
                      className="h-7 px-3 text-xs"
                      onClick={() => handleAcceptRequest(request.id)}
                    >
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 px-3 text-xs"
                      onClick={() => handleDeclineRequest(request.id)}
                    >
                      Decline
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Suggestions Section */}
      <div>
        <h3 className="font-semibold text-lg mb-4">Suggestions for you</h3>
        <div className="space-y-4">
          {suggestedUsers.map((user) => (
            <div key={user.id} className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src={user.profilePicture || "/placeholder.svg"} alt={user.displayName} />
                <AvatarFallback>{user.displayName.substring(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{user.displayName}</p>
                <p className="text-xs text-muted-foreground">{user.location}</p>
              </div>
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-primary"
                onClick={() => handleFollow(user.id)}
              >
                <UserPlus className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="link" className="text-xs w-full">
            View All
          </Button>
        </div>
      </div>

      {/* Followers Section */}
      <div className="mt-8 pt-4 border-t border-border">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex -space-x-2">
            {[1, 2, 3, 4, 5, 6, 7].map((i) => (
              <Avatar key={i} className="border-2 border-background w-8 h-8">
                <AvatarImage src={`/placeholder.svg?${i}`} alt={`Follower ${i}`} />
                <AvatarFallback>F{i}</AvatarFallback>
              </Avatar>
            ))}
          </div>
          <div>
            <p className="font-semibold">
              184.3K <span className="text-xs font-normal text-muted-foreground">Followers</span>
            </p>
            <p className="text-xs text-muted-foreground">Active now on your profile</p>
          </div>
        </div>
      </div>

      {/* Footer Links */}
      <div className="mt-8 pt-4 border-t border-border text-xs text-muted-foreground">
        <div className="flex flex-wrap gap-x-4 gap-y-2">
          <a href="#" className="hover:underline">
            About
          </a>
          <a href="#" className="hover:underline">
            Accessibility
          </a>
          <a href="#" className="hover:underline">
            Help Center
          </a>
          <a href="#" className="hover:underline">
            Privacy and Terms
          </a>
          <a href="#" className="hover:underline">
            Advertising
          </a>
          <a href="#" className="hover:underline">
            Business Services
          </a>
        </div>
      </div>
    </div>
  )
}
