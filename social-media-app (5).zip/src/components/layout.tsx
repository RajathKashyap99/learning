import { Outlet } from "react-router-dom"
import Sidebar from "@/components/sidebar"
import RightSidebar from "@/components/right-sidebar"

export default function Layout() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 border-x border-border">
        <Outlet />
      </main>
      <RightSidebar />
    </div>
  )
}
