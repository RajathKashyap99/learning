"use client"

import { Link, useLocation } from "react-router-dom"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/context/auth-context"
import { Home, Compass, Bookmark, MessageSquare, BarChart2, Settings } from "lucide-react"

export default function Sidebar() {
  const location = useLocation()
  const { user } = useAuth()

  const navItems = [
    { path: "/", label: "Feed", icon: Home },
    { path: "/explore", label: "Explore", icon: Compass },
    { path: "/favorites", label: "My favorites", icon: Bookmark },
    { path: "/direct", label: "Direct", icon: MessageSquare },
    { path: "/stats", label: "Stats", icon: BarChart2 },
    { path: "/settings", label: "Settings", icon: Settings },
  ]

  return (
    <div className="w-64 shrink-0 border-r border-border bg-background p-4 flex flex-col h-screen sticky top-0">
      {user && (
        <div className="mb-8">
          <Link to={`/profile/${user.username}`} className="flex flex-col items-center">
            <Avatar className="h-16 w-16 mb-2">
              <AvatarImage src={user.profilePicture || "/placeholder.svg"} alt={user.username} />
              <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="text-center">
              <h2 className="font-semibold text-lg">{user.displayName}</h2>
              <p className="text-xs text-muted-foreground">{user.location}</p>
            </div>
          </Link>

          <div className="flex justify-between mt-4 text-center">
            <div>
              <p className="font-semibold">{user.posts}</p>
              <p className="text-xs text-muted-foreground">Posts</p>
            </div>
            <div>
              <p className="font-semibold">{user.followers}</p>
              <p className="text-xs text-muted-foreground">Followers</p>
            </div>
            <div>
              <p className="font-semibold">{user.following}</p>
              <p className="text-xs text-muted-foreground">Following</p>
            </div>
          </div>
        </div>
      )}

      <nav className="space-y-1 flex-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path
          const Icon = item.icon

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{item.label}</span>
            </Link>
          )
        })}
      </nav>

      <div className="mt-auto pt-4 border-t border-border">
        <h3 className="font-semibold mb-2">Contacts</h3>
        <div className="space-y-2">
          {/* We'll populate this with actual contacts later */}
          <div className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-accent cursor-pointer">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder.svg" alt="Contact" />
              <AvatarFallback>JM</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">Julie Mendez</p>
              <p className="text-xs text-muted-foreground truncate">Memphis, TN, US</p>
            </div>
            <button className="text-primary">
              <MessageSquare className="h-4 w-4" />
            </button>
          </div>

          <Link to="/contacts" className="text-sm text-primary block text-center mt-2">
            View All
          </Link>
        </div>
      </div>
    </div>
  )
}
