"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

type Story = {
  id: string
  username: string
  profilePicture: string
  viewed: boolean
}

export default function Stories() {
  const [stories, setStories] = useState<Story[]>([
    { id: "1", username: "Add story", profilePicture: "", viewed: false },
    { id: "2", username: "Chloe", profilePicture: "/placeholder.svg?1", viewed: false },
    { id: "3", username: "Jasmine", profilePicture: "/placeholder.svg?2", viewed: false },
    { id: "4", username: "Amelia", profilePicture: "/placeholder.svg?3", viewed: true },
    { id: "5", username: "Grace", profilePicture: "/placeholder.svg?4", viewed: false },
    { id: "6", username: "Sophia", profilePicture: "/placeholder.svg?5", viewed: true },
    { id: "7", username: "Emma", profilePicture: "/placeholder.svg?6", viewed: false },
  ])

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Stories</h2>
        <Button variant="link" className="text-sm">
          Watch all
        </Button>
      </div>

      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-4 pb-4">
          {stories.map((story, index) => (
            <div key={story.id} className="flex flex-col items-center space-y-1">
              <div
                className={`p-0.5 rounded-full ${
                  index === 0
                    ? "bg-background"
                    : story.viewed
                      ? "bg-muted"
                      : "bg-gradient-to-tr from-pink-500 to-blue-500"
                }`}
              >
                <div className="bg-background p-0.5 rounded-full">
                  {index === 0 ? (
                    <Button variant="outline" size="icon" className="h-14 w-14 rounded-full border-dashed">
                      <Plus className="h-6 w-6" />
                      <span className="sr-only">Add story</span>
                    </Button>
                  ) : (
                    <Avatar className="h-14 w-14 border-2 border-background">
                      <AvatarImage src={story.profilePicture || "/placeholder.svg"} alt={story.username} />
                      <AvatarFallback>{story.username.substring(0, 2)}</AvatarFallback>
                    </Avatar>
                  )}
                </div>
              </div>
              <span className="text-xs">{story.username}</span>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
