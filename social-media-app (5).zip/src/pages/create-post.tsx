"use client"

import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { ImageIcon, X } from "lucide-react"

export default function CreatePost() {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [content, setContent] = useState("")
  const [images, setImages] = useState<string[]>([])
  const [loading, setLoading] = useState(false)

  const handleAddImage = () => {
    // In a real app, you would use a file input and upload the image
    // For this demo, we'll just add a placeholder
    setImages((prev) => [...prev, `/placeholder.svg?height=400&width=400&${Date.now()}`])
  }

  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!content.trim() && images.length === 0) {
      toast({
        title: "Error",
        description: "Please add some content or images to your post",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    // In a real app, you would make an API call to create the post
    setTimeout(() => {
      toast({
        title: "Success",
        description: "Your post has been created",
      })
      setLoading(false)
      navigate("/")
    }, 1500)
  }

  return (
    <div className="max-w-2xl mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Create new post</CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent>
            <Textarea
              placeholder="What's on your mind?"
              className="min-h-32 mb-4"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />

            {images.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
                {images.map((image, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Upload ${index + 1}`}
                      className="w-full h-32 object-cover rounded-md"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => handleRemoveImage(index)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <Button type="button" variant="outline" className="w-full h-32 border-dashed" onClick={handleAddImage}>
              <div className="flex flex-col items-center">
                <ImageIcon className="h-8 w-8 mb-2 text-muted-foreground" />
                <span className="text-muted-foreground">Add photos</span>
              </div>
            </Button>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Posting..." : "Post"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
