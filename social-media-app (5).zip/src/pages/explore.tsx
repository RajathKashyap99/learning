"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"

export default function Explore() {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, you would fetch trending posts from an API
    setTimeout(() => {
      setPosts(
        Array.from({ length: 12 }, (_, i) => ({
          id: `explore-${i}`,
          image: `/placeholder.svg?height=400&width=400&${i}`,
          likes: Math.floor(Math.random() * 10000),
          comments: Math.floor(Math.random() * 500),
        })),
      )
      setLoading(false)
    }, 1000)
  }, [])

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-4">Explore</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input placeholder="Search" className="pl-10" />
        </div>
      </div>

      <Tabs defaultValue="trending">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="latest">Latest</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>

        <TabsContent value="trending">
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="aspect-square bg-muted rounded-md animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {posts.map((post) => (
                <div key={post.id} className="group relative aspect-square overflow-hidden rounded-md">
                  <img
                    src={post.image || "/placeholder.svg"}
                    alt="Explore post"
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="flex gap-4 text-white">
                      <div className="flex items-center gap-1">
                        <span>❤️</span>
                        <span>{post.likes.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span>💬</span>
                        <span>{post.comments.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="latest">
          <div className="text-center text-muted-foreground py-8">Latest content will appear here</div>
        </TabsContent>

        <TabsContent value="following">
          <div className="text-center text-muted-foreground py-8">Content from people you follow will appear here</div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
