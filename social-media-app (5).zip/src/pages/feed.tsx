"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PostCard from "@/components/post-card"
import Stories from "@/components/stories"
import CreatePostButton from "@/components/create-post-button"

export default function Feed() {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, you would fetch posts from an API
    setTimeout(() => {
      setPosts([
        {
          id: "1",
          user: {
            id: "101",
            username: "robertfox",
            displayName: "Robert Fox",
            profilePicture: "/placeholder.svg?user1",
          },
          content:
            "While Corfu give us the ability to shoot by the sea with amazing blue background full of light of the sky, Florina give us its gentle side. The humble atmosphere and Light of Florina which comes...",
          images: [
            "/placeholder.svg?height=600&width=600&1",
            "/placeholder.svg?height=300&width=300&2",
            "/placeholder.svg?height=300&width=300&3",
            "/placeholder.svg?height=300&width=300&4",
          ],
          likes: 1600,
          comments: 2300,
          createdAt: "2023-05-15T10:30:00Z",
          hashtags: ["#landscape", "#flora", "#nature"],
        },
        {
          id: "2",
          user: {
            id: "102",
            username: "diannerussell",
            displayName: "Dianne Russell",
            profilePicture: "/placeholder.svg?user2",
          },
          content:
            "The beauty of nature never ceases to amaze me. Every sunset is a reminder of how precious our planet is.",
          images: ["/placeholder.svg?height=400&width=800&5"],
          likes: 2400,
          comments: 120,
          createdAt: "2023-05-14T15:45:00Z",
        },
      ])
      setLoading(false)
    }, 1000)
  }, [])

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Feeds</h1>
        <CreatePostButton />
      </div>

      <Stories />

      <Tabs defaultValue="popular" className="mb-6">
        <TabsList className="grid w-full grid-cols-2 max-w-[200px]">
          <TabsTrigger value="popular">Popular</TabsTrigger>
          <TabsTrigger value="latest">Latest</TabsTrigger>
        </TabsList>
        <TabsContent value="popular">
          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <div key={i} className="rounded-lg border border-border animate-pulse">
                  <div className="p-4 flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-muted"></div>
                    <div className="flex-1">
                      <div className="h-4 w-24 bg-muted rounded"></div>
                      <div className="h-3 w-16 bg-muted rounded mt-2"></div>
                    </div>
                  </div>
                  <div className="aspect-square bg-muted"></div>
                  <div className="p-4">
                    <div className="h-4 w-full bg-muted rounded"></div>
                    <div className="h-4 w-2/3 bg-muted rounded mt-2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div>
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </TabsContent>
        <TabsContent value="latest">
          {/* Similar content for latest tab */}
          <div className="text-center text-muted-foreground py-8">Latest posts will appear here</div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
