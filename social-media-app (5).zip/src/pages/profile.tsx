"use client"

import { useState, useEffect } from "react"
import { useParams } from "react-router-dom"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Grid3X3, Bookmark, Settings } from "lucide-react"
import PostCard from "@/components/post-card"

export default function Profile() {
  const { username } = useParams<{ username: string }>()
  const [profile, setProfile] = useState<any>(null)
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [isFollowing, setIsFollowing] = useState(false)

  useEffect(() => {
    // In a real app, you would fetch profile data from an API
    setTimeout(() => {
      setProfile({
        id: "1",
        username: "cyndylillibridge",
        displayName: "Cyndy Lillibridge",
        profilePicture: "/placeholder.svg?user1",
        location: "Torrance, CA, United States",
        bio: "Photographer and nature lover",
        posts: 368,
        followers: 184300,
        following: 1040000,
      })

      setPosts([
        {
          id: "1",
          user: {
            id: "1",
            username: "cyndylillibridge",
            displayName: "Cyndy Lillibridge",
            profilePicture: "/placeholder.svg?user1",
          },
          content: "Beautiful sunset at the beach today!",
          images: ["/placeholder.svg?height=600&width=600&1"],
          likes: 1200,
          comments: 45,
          createdAt: "2023-05-15T10:30:00Z",
        },
        {
          id: "2",
          user: {
            id: "1",
            username: "cyndylillibridge",
            displayName: "Cyndy Lillibridge",
            profilePicture: "/placeholder.svg?user1",
          },
          content: "Morning hike with amazing views",
          images: [
            "/placeholder.svg?height=300&width=300&2",
            "/placeholder.svg?height=300&width=300&3",
            "/placeholder.svg?height=300&width=300&4",
            "/placeholder.svg?height=300&width=300&5",
          ],
          likes: 980,
          comments: 32,
          createdAt: "2023-05-14T08:15:00Z",
        },
      ])

      setLoading(false)
    }, 1000)
  }, [username])

  const handleFollowToggle = () => {
    setIsFollowing(!isFollowing)
    // In a real app, you would make an API call here
  }

  if (loading) {
    return (
      <div className="p-4 max-w-4xl mx-auto animate-pulse">
        <div className="flex flex-col md:flex-row gap-6 mb-8">
          <div className="w-32 h-32 rounded-full bg-muted mx-auto md:mx-0"></div>
          <div className="flex-1">
            <div className="h-8 w-48 bg-muted rounded mb-4"></div>
            <div className="h-4 w-64 bg-muted rounded mb-6"></div>
            <div className="flex gap-8 mb-4">
              <div className="h-6 w-20 bg-muted rounded"></div>
              <div className="h-6 w-20 bg-muted rounded"></div>
              <div className="h-6 w-20 bg-muted rounded"></div>
            </div>
            <div className="h-10 w-32 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="p-4 text-center">
        <h1 className="text-2xl font-bold mb-2">User not found</h1>
        <p className="text-muted-foreground">The user you're looking for doesn't exist or has been removed.</p>
      </div>
    )
  }

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <Avatar className="w-32 h-32 mx-auto md:mx-0">
          <AvatarImage src={profile.profilePicture || "/placeholder.svg"} alt={profile.displayName} />
          <AvatarFallback>{profile.displayName.substring(0, 2)}</AvatarFallback>
        </Avatar>

        <div className="flex-1 text-center md:text-left">
          <h1 className="text-2xl font-bold mb-1">{profile.displayName}</h1>
          <p className="text-sm text-muted-foreground mb-4">{profile.location}</p>

          <div className="flex justify-center md:justify-start gap-8 mb-4">
            <div className="text-center">
              <p className="font-semibold">{profile.posts.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Posts</p>
            </div>
            <div className="text-center">
              <p className="font-semibold">{(profile.followers / 1000).toFixed(1)}K</p>
              <p className="text-xs text-muted-foreground">Followers</p>
            </div>
            <div className="text-center">
              <p className="font-semibold">{(profile.following / 1000000).toFixed(2)}M</p>
              <p className="text-xs text-muted-foreground">Following</p>
            </div>
          </div>

          <div className="flex gap-2 justify-center md:justify-start">
            <Button variant={isFollowing ? "outline" : "default"} onClick={handleFollowToggle}>
              {isFollowing ? "Following" : "Follow"}
            </Button>
            <Button variant="outline">Message</Button>
            <Button variant="outline" size="icon">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="posts">
        <TabsList className="grid w-full grid-cols-2 max-w-[200px] mx-auto">
          <TabsTrigger value="posts">
            <Grid3X3 className="h-4 w-4 mr-2" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="saved">
            <Bookmark className="h-4 w-4 mr-2" />
            Saved
          </TabsTrigger>
        </TabsList>
        <TabsContent value="posts" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="saved" className="mt-6">
          <div className="text-center text-muted-foreground py-8">No saved posts yet</div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
