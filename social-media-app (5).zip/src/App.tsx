import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { Toaster } from "@/components/ui/toaster"
import { ThemeProvider } from "@/components/theme-provider"
import Layout from "@/components/layout"
import Feed from "@/pages/feed"
import Profile from "@/pages/profile"
import Explore from "@/pages/explore"
import Favorites from "@/pages/favorites"
import Direct from "@/pages/direct"
import Stats from "@/pages/stats"
import Settings from "@/pages/settings"
import CreatePost from "@/pages/create-post"
import Login from "@/pages/login"
import Register from "@/pages/register"
import { AuthProvider } from "@/context/auth-context"
import ProtectedRoute from "@/components/protected-route"

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="social-media-theme">
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route element={<ProtectedRoute />}>
              <Route element={<Layout />}>
                <Route path="/" element={<Feed />} />
                <Route path="/profile/:username" element={<Profile />} />
                <Route path="/explore" element={<Explore />} />
                <Route path="/favorites" element={<Favorites />} />
                <Route path="/direct" element={<Direct />} />
                <Route path="/stats" element={<Stats />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/create-post" element={<CreatePost />} />
              </Route>
            </Route>
          </Routes>
        </Router>
        <Toaster />
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
