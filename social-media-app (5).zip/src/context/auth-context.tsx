"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type User = {
  id: string
  username: string
  displayName: string
  email: string
  profilePicture: string
  location: string
  bio: string
  posts: number
  followers: number
  following: number
}

type AuthContextType = {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (userData: Partial<User> & { password: string }) => Promise<void>
  logout: () => void
  updateProfile: (userData: Partial<User>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string) => {
    setLoading(true)
    try {
      // In a real app, you would make an API call here
      // For demo purposes, we'll simulate a successful login
      const mockUser: User = {
        id: "1",
        username: "cyndylillibridge",
        displayName: "Cyndy Lillibridge",
        email: email,
        profilePicture: "/placeholder.svg?user1",
        location: "Torrance, CA, United States",
        bio: "Photographer and nature lover",
        posts: 368,
        followers: 184300,
        following: 1040000,
      }

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } catch (error) {
      console.error("Login failed:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const register = async (userData: Partial<User> & { password: string }) => {
    setLoading(true)
    try {
      // In a real app, you would make an API call here
      // For demo purposes, we'll simulate a successful registration
      const mockUser: User = {
        id: "1",
        username: userData.username || "newuser",
        displayName: userData.displayName || "New User",
        email: userData.email || "user@example.com",
        profilePicture: userData.profilePicture || "/placeholder.svg?user1",
        location: userData.location || "United States",
        bio: userData.bio || "",
        posts: 0,
        followers: 0,
        following: 0,
      }

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } catch (error) {
      console.error("Registration failed:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  const updateProfile = async (userData: Partial<User>) => {
    setLoading(true)
    try {
      // In a real app, you would make an API call here
      if (user) {
        const updatedUser = { ...user, ...userData }
        setUser(updatedUser)
        localStorage.setItem("user", JSON.stringify(updatedUser))
      }
    } catch (error) {
      console.error("Profile update failed:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
