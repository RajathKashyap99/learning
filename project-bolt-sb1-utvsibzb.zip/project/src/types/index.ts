// User types
export interface User {
  _id: string;
  username: string;
  email: string;
  name: string;
  bio?: string;
  avatar?: string;
  coverImage?: string;
  location?: string;
  website?: string;
  following: string[];
  followers: string[];
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile extends User {
  postsCount: number;
}

export interface UserCredentials {
  email: string;
  password: string;
}

export interface UserRegistration extends UserCredentials {
  username: string;
  name: string;
}

// Post types
export interface Post {
  _id: string;
  text: string;
  images?: string[];
  author: User;
  likes: string[];
  commentsCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  _id: string;
  text: string;
  post: string;
  author: User;
  likes: string[];
  createdAt: string;
  updatedAt: string;
}

export interface CreatePostData {
  text: string;
  images?: File[];
}

export interface CreateCommentData {
  text: string;
  postId: string;
}

// Auth types
export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// API response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    hasMore: boolean;
  };
}

// Notification types
export interface Notification {
  _id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  sender: User;
  recipient: string;
  post?: string;
  comment?: string;
  read: boolean;
  createdAt: string;
}

// Application State types
export interface AppState {
  darkMode: boolean;
  sidebarOpen: boolean;
}