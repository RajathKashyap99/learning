import api from './api';
import { User, UserProfile, PaginatedResponse } from '@/types';

export const getProfile = async (username: string): Promise<UserProfile> => {
  try {
    const response = await api.get(`/users/profile/${username}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const searchUsers = async (query: string, page = 1, limit = 10): Promise<PaginatedResponse<User>> => {
  try {
    const response = await api.get(`/users/search?q=${query}&page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getFollowers = async (
  userId: string,
  page = 1,
  limit = 10
): Promise<PaginatedResponse<User>> => {
  try {
    const response = await api.get(`/users/${userId}/followers?page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getFollowing = async (
  userId: string,
  page = 1,
  limit = 10
): Promise<PaginatedResponse<User>> => {
  try {
    const response = await api.get(`/users/${userId}/following?page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const followUser = async (userId: string): Promise<User> => {
  try {
    const response = await api.post(`/users/${userId}/follow`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const unfollowUser = async (userId: string): Promise<User> => {
  try {
    const response = await api.delete(`/users/${userId}/follow`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getSuggestedUsers = async (limit = 5): Promise<User[]> => {
  try {
    const response = await api.get(`/users/suggested?limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};