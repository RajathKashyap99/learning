import api from './api';
import { Post, CreatePostData, Comment, CreateCommentData, PaginatedResponse } from '@/types';

export const getPosts = async (page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
  try {
    const response = await api.get(`/posts?page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getUserPosts = async (
  userId: string,
  page = 1,
  limit = 10
): Promise<PaginatedResponse<Post>> => {
  try {
    const response = await api.get(`/posts/user/${userId}?page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getPost = async (postId: string): Promise<Post> => {
  try {
    const response = await api.get(`/posts/${postId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createPost = async (postData: CreatePostData): Promise<Post> => {
  try {
    const formData = new FormData();
    formData.append('text', postData.text);
    
    if (postData.images && postData.images.length > 0) {
      postData.images.forEach((image, index) => {
        formData.append('images', image);
      });
    }
    
    const response = await api.post('/posts', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const updatePost = async (postId: string, text: string): Promise<Post> => {
  try {
    const response = await api.put(`/posts/${postId}`, { text });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const deletePost = async (postId: string): Promise<void> => {
  try {
    await api.delete(`/posts/${postId}`);
  } catch (error) {
    throw error;
  }
};

export const likePost = async (postId: string): Promise<Post> => {
  try {
    const response = await api.post(`/posts/${postId}/like`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const unlikePost = async (postId: string): Promise<Post> => {
  try {
    const response = await api.delete(`/posts/${postId}/like`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getComments = async (
  postId: string,
  page = 1,
  limit = 10
): Promise<PaginatedResponse<Comment>> => {
  try {
    const response = await api.get(`/posts/${postId}/comments?page=${page}&limit=${limit}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createComment = async (commentData: CreateCommentData): Promise<Comment> => {
  try {
    const response = await api.post(`/posts/${commentData.postId}/comments`, {
      text: commentData.text,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const deleteComment = async (postId: string, commentId: string): Promise<void> => {
  try {
    await api.delete(`/posts/${postId}/comments/${commentId}`);
  } catch (error) {
    throw error;
  }
};