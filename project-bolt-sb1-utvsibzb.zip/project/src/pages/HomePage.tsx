import { useState, useEffect, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import InfiniteScroll from 'react-infinite-scroll-component';
import { Post } from '@/types';
import { getPosts } from '@/services/postService';
import { CreatePostForm } from '@/components/post/CreatePostForm';
import { PostCard } from '@/components/post/PostCard';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export const HomePage: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const fetchPosts = useCallback(async (pageNum: number) => {
    try {
      setLoading(true);
      const response = await getPosts(pageNum);
      
      if (pageNum === 1) {
        setPosts(response.data);
      } else {
        setPosts(prev => [...prev, ...response.data]);
      }
      
      setHasMore(response.pagination.hasMore);
      setError(null);
    } catch (error) {
      setError('Failed to load posts. Please try again later.');
      toast.error('Failed to load posts');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPosts(1);
  }, [fetchPosts]);

  const handleLoadMore = () => {
    if (!hasMore || loading) return;
    
    const nextPage = page + 1;
    setPage(nextPage);
    fetchPosts(nextPage);
  };

  const handlePostCreated = () => {
    setPage(1);
    fetchPosts(1);
  };

  const handlePostDelete = (postId: string) => {
    setPosts(prev => prev.filter(post => post._id !== postId));
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Home</h1>
      
      <CreatePostForm onPostCreated={handlePostCreated} />
      
      {loading && posts.length === 0 ? (
        <div className="space-y-4">
          {Array(3).fill(0).map((_, index) => (
            <div key={index} className="bg-card rounded-lg shadow-sm border border-border p-4">
              <div className="flex items-start space-x-4 mb-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              </div>
              <Skeleton className="h-24 w-full mb-4" />
              <div className="flex justify-between">
                <Skeleton className="h-8 w-16" />
                <Skeleton className="h-8 w-16" />
                <Skeleton className="h-8 w-16" />
                <Skeleton className="h-8 w-16" />
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="text-center py-8">
          <p className="text-destructive">{error}</p>
          <button
            onClick={() => fetchPosts(1)}
            className="mt-4 text-primary hover:underline"
          >
            Try Again
          </button>
        </div>
      ) : (
        <InfiniteScroll
          dataLength={posts.length}
          next={handleLoadMore}
          hasMore={hasMore}
          loader={
            <div className="py-4 text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <span className="sr-only">Loading...</span>
            </div>
          }
          endMessage={
            <p className="text-center text-muted-foreground py-4">
              You've seen all posts
            </p>
          }
        >
          <AnimatePresence mode="popLayout">
            {posts.map(post => (
              <motion.div
                key={post._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.2 }}
                layout
              >
                <PostCard post={post} onDelete={handlePostDelete} />
              </motion.div>
            ))}
          </AnimatePresence>
        </InfiniteScroll>
      )}
    </div>
  );
};