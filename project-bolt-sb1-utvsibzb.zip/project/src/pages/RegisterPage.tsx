import { RegisterForm } from '@/components/auth/RegisterForm';

export const RegisterPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-dark to-primary/60 p-4">
      <div className="max-w-md w-full">
        <RegisterForm />
      </div>
    </div>
  );
};