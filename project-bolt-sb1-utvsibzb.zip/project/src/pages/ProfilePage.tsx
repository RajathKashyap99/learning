import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserProfile, Post } from '@/types';
import { getProfile } from '@/services/userService';
import { getUserPosts } from '@/services/postService';
import { ProfileHeader } from '@/components/profile/ProfileHeader';
import { PostCard } from '@/components/post/PostCard';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'sonner';

export const ProfilePage: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('posts');

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!username) return;
      
      try {
        setLoading(true);
        
        const profileData = await getProfile(username);
        setProfile(profileData);
        
        // Check if current user is following this profile
        if (user) {
          setIsFollowing(profileData.followers.includes(user._id));
        }
        
        // Fetch user posts
        const postsData = await getUserPosts(profileData._id);
        setPosts(postsData.data);
      } catch (error) {
        toast.error('Failed to load profile');
        navigate('/not-found');
      } finally {
        setLoading(false);
      }
    };
    
    fetchProfileData();
  }, [username, user, navigate]);

  const handlePostDelete = (postId: string) => {
    setPosts(prev => prev.filter(post => post._id !== postId));
    
    // Update post count in profile
    if (profile) {
      setProfile({
        ...profile,
        postsCount: profile.postsCount - 1
      });
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-48 bg-muted rounded-t-lg"></div>
        <div className="h-32 px-6">
          <div className="h-6 bg-muted rounded w-1/3 mb-2"></div>
          <div className="h-4 bg-muted rounded w-1/4 mb-4"></div>
          <div className="h-4 bg-muted rounded w-full mb-2"></div>
          <div className="h-4 bg-muted rounded w-2/3"></div>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold">User not found</h2>
        <p className="text-muted-foreground mt-2">
          The user you're looking for doesn't exist or has been removed.
        </p>
      </div>
    );
  }

  return (
    <div>
      <ProfileHeader 
        profile={profile} 
        isFollowing={isFollowing} 
        setIsFollowing={setIsFollowing} 
      />
      
      <Tabs defaultValue="posts" onValueChange={setActiveTab} className="mt-6">
        <div className="border-b border-border">
          <TabsList className="w-full justify-start bg-transparent h-auto p-0">
            <TabsTrigger 
              value="posts" 
              className="rounded-none px-6 py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none data-[state=active]:bg-transparent"
            >
              Posts
            </TabsTrigger>
            <TabsTrigger 
              value="replies" 
              className="rounded-none px-6 py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none data-[state=active]:bg-transparent"
            >
              Replies
            </TabsTrigger>
            <TabsTrigger 
              value="media" 
              className="rounded-none px-6 py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none data-[state=active]:bg-transparent"
            >
              Media
            </TabsTrigger>
            <TabsTrigger 
              value="likes" 
              className="rounded-none px-6 py-3 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none data-[state=active]:bg-transparent"
            >
              Likes
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="posts" className="mt-6 space-y-4">
          {posts.length > 0 ? (
            posts.map(post => (
              <PostCard 
                key={post._id} 
                post={post} 
                onDelete={handlePostDelete} 
              />
            ))
          ) : (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium">No posts yet</h3>
              <p className="text-muted-foreground mt-2">
                When {profile.username === user?.username ? 'you post' : `${profile.name} posts`} something, it will show up here.
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="replies" className="mt-6">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium">No replies yet</h3>
            <p className="text-muted-foreground mt-2">
              When {profile.username === user?.username ? 'you reply' : `${profile.name} replies`} to a post, it will show up here.
            </p>
          </div>
        </TabsContent>
        
        <TabsContent value="media" className="mt-6">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium">No media yet</h3>
            <p className="text-muted-foreground mt-2">
              When {profile.username === user?.username ? 'you post' : `${profile.name} posts`} photos or videos, they will show up here.
            </p>
          </div>
        </TabsContent>
        
        <TabsContent value="likes" className="mt-6">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium">No likes yet</h3>
            <p className="text-muted-foreground mt-2">
              Posts {profile.username === user?.username ? 'you have' : `${profile.name} has`} liked will show up here.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};