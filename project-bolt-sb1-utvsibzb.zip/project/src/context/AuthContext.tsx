import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';
import { AuthState, User, UserCredentials, UserRegistration, ApiResponse } from '@/types';
import { loginUser, registerUser, getCurrentUser } from '@/services/authService';
import { toast } from 'sonner';

// Define the Auth Context type
interface AuthContextType extends AuthState {
  login: (credentials: UserCredentials) => Promise<void>;
  register: (userData: UserRegistration) => Promise<void>;
  logout: () => void;
  updateUserProfile: (updatedUser: Partial<User>) => void;
}

// Create the Auth Context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Auth reducer actions
type AuthAction =
  | { type: 'LOGIN_START' | 'REGISTER_START' | 'LOAD_USER_START' }
  | { type: 'LOGIN_SUCCESS' | 'REGISTER_SUCCESS'; payload: { user: User; token: string } }
  | { type: 'LOGIN_FAILURE' | 'REGISTER_FAILURE' | 'LOAD_USER_FAILURE'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'LOAD_USER_SUCCESS'; payload: User }
  | { type: 'UPDATE_USER'; payload: Partial<User> };

// Auth reducer
const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN_START':
    case 'REGISTER_START':
    case 'LOAD_USER_START':
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    case 'LOGIN_SUCCESS':
    case 'REGISTER_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isAuthenticated: true,
        user: action.payload.user,
        token: action.payload.token,
        error: null,
      };
    case 'LOGIN_FAILURE':
    case 'REGISTER_FAILURE':
    case 'LOAD_USER_FAILURE':
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        user: null,
        token: null,
        error: action.payload,
      };
    case 'LOGOUT':
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        token: null,
      };
    case 'LOAD_USER_SUCCESS':
      return {
        ...state,
        isLoading: false,
        isAuthenticated: true,
        user: action.payload,
        error: null,
      };
    case 'UPDATE_USER':
      return {
        ...state,
        user: state.user ? { ...state.user, ...action.payload } : null,
      };
    default:
      return state;
  }
};

// Initial state
const initialState: AuthState = {
  user: null,
  token: localStorage.getItem('token'),
  isAuthenticated: false,
  isLoading: true,
  error: null,
};

// Auth Provider Component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Load user on initial app load if token exists
  useEffect(() => {
    const loadUser = async () => {
      const token = localStorage.getItem('token');
      
      if (!token) {
        dispatch({ type: 'LOAD_USER_FAILURE', payload: 'No token found' });
        return;
      }
      
      // Check if token is expired
      try {
        const decoded: any = jwtDecode(token);
        const currentTime = Date.now() / 1000;
        
        if (decoded.exp < currentTime) {
          localStorage.removeItem('token');
          dispatch({ type: 'LOGOUT' });
          return;
        }
        
        dispatch({ type: 'LOAD_USER_START' });
        
        try {
          const userData = await getCurrentUser();
          dispatch({ type: 'LOAD_USER_SUCCESS', payload: userData });
        } catch (error) {
          localStorage.removeItem('token');
          dispatch({ 
            type: 'LOAD_USER_FAILURE', 
            payload: error instanceof Error ? error.message : 'Failed to load user'
          });
        }
      } catch (error) {
        localStorage.removeItem('token');
        dispatch({ type: 'LOGOUT' });
      }
    };
    
    loadUser();
  }, []);

  // Login function
  const login = async (credentials: UserCredentials) => {
    dispatch({ type: 'LOGIN_START' });
    
    try {
      const response = await loginUser(credentials);
      const { user, token } = response;
      
      localStorage.setItem('token', token);
      dispatch({ type: 'LOGIN_SUCCESS', payload: { user, token } });
      
      toast.success('Welcome back!');
    } catch (error) {
      dispatch({ 
        type: 'LOGIN_FAILURE', 
        payload: error instanceof Error ? error.message : 'Login failed'
      });
      
      toast.error(error instanceof Error ? error.message : 'Login failed');
    }
  };

  // Register function
  const register = async (userData: UserRegistration) => {
    dispatch({ type: 'REGISTER_START' });
    
    try {
      const response = await registerUser(userData);
      const { user, token } = response;
      
      localStorage.setItem('token', token);
      dispatch({ type: 'REGISTER_SUCCESS', payload: { user, token } });
      
      toast.success('Registration successful!');
    } catch (error) {
      dispatch({ 
        type: 'REGISTER_FAILURE',
        payload: error instanceof Error ? error.message : 'Registration failed'
      });
      
      toast.error(error instanceof Error ? error.message : 'Registration failed');
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('token');
    dispatch({ type: 'LOGOUT' });
    toast.info('You have been logged out');
  };

  // Update user profile
  const updateUserProfile = (updatedUser: Partial<User>) => {
    dispatch({ type: 'UPDATE_USER', payload: updatedUser });
  };

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        register,
        logout,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook for using Auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};