import React from 'react';
import { Link } from 'react-router-dom';
import { Edit, Calendar, MapPin, Link as LinkIcon } from 'lucide-react';
import { format } from 'date-fns';
import { UserProfile } from '@/types';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { followUser, unfollowUser } from '@/services/userService';
import { toast } from 'sonner';

interface ProfileHeaderProps {
  profile: UserProfile;
  isFollowing: boolean;
  setIsFollowing: React.Dispatch<React.SetStateAction<boolean>>;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = ({
  profile,
  isFollowing,
  setIsFollowing,
}) => {
  const { user } = useAuth();
  const isCurrentUser = user?._id === profile._id;

  const handleFollowToggle = async () => {
    try {
      if (isFollowing) {
        await unfollowUser(profile._id);
        setIsFollowing(false);
        toast.success(`Unfollowed ${profile.name}`);
      } else {
        await followUser(profile._id);
        setIsFollowing(true);
        toast.success(`Following ${profile.name}`);
      }
    } catch (error) {
      toast.error('Failed to update follow status');
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <div className="mb-6">
      <div className="relative">
        <div className="h-48 bg-gradient-to-r from-primary-dark to-primary rounded-t-lg overflow-hidden">
          {profile.coverImage && (
            <img 
              src={profile.coverImage} 
              alt="Cover" 
              className="w-full h-full object-cover"
            />
          )}
        </div>
        <div className="absolute -bottom-16 left-6">
          <Avatar className="h-32 w-32 rounded-full border-4 border-background">
            <AvatarImage 
              src={profile.avatar} 
              alt={profile.name} 
            />
            <AvatarFallback className="text-2xl">
              {getInitials(profile.name)}
            </AvatarFallback>
          </Avatar>
        </div>
        <div className="absolute bottom-4 right-4">
          {isCurrentUser ? (
            <Button as={Link} to="/settings" variant="outline" size="sm">
              <Edit className="mr-1 h-4 w-4" />
              Edit Profile
            </Button>
          ) : (
            <Button
              variant={isFollowing ? "outline" : "default"}
              size="sm"
              onClick={handleFollowToggle}
            >
              {isFollowing ? 'Following' : 'Follow'}
            </Button>
          )}
        </div>
      </div>

      <div className="mt-16 px-6 pt-2">
        <h1 className="text-2xl font-bold">{profile.name}</h1>
        <p className="text-muted-foreground">@{profile.username}</p>
        
        {profile.bio && <p className="mt-2">{profile.bio}</p>}
        
        <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
          {profile.location && (
            <div className="flex items-center">
              <MapPin className="mr-1 h-4 w-4" />
              <span>{profile.location}</span>
            </div>
          )}
          
          {profile.website && (
            <div className="flex items-center">
              <LinkIcon className="mr-1 h-4 w-4" />
              <a 
                href={profile.website.startsWith('http') ? profile.website : `https://${profile.website}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                {profile.website.replace(/^https?:\/\//, '')}
              </a>
            </div>
          )}
          
          <div className="flex items-center">
            <Calendar className="mr-1 h-4 w-4" />
            <span>Joined {format(new Date(profile.createdAt), 'MMMM yyyy')}</span>
          </div>
        </div>
        
        <div className="flex gap-4 mt-4">
          <Link 
            to={`/profile/${profile.username}/following`}
            className="text-sm hover:underline"
          >
            <span className="font-semibold">{profile.following.length}</span>{' '}
            <span className="text-muted-foreground">Following</span>
          </Link>
          <Link 
            to={`/profile/${profile.username}/followers`}
            className="text-sm hover:underline"
          >
            <span className="font-semibold">{profile.followers.length}</span>{' '}
            <span className="text-muted-foreground">Followers</span>
          </Link>
          <div className="text-sm">
            <span className="font-semibold">{profile.postsCount}</span>{' '}
            <span className="text-muted-foreground">Posts</span>
          </div>
        </div>
      </div>
    </div>
  );
};