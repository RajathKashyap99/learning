import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { 
  Home, Search, Bell, Mail, BookmarkIcon, User, Settings, Menu, X, LogOut 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { useAuth } from '@/context/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  expanded: boolean;
  notifications?: number;
}

const NavItem: React.FC<NavItemProps> = ({ 
  to, icon, label, expanded, notifications 
}) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <NavLink 
            to={to} 
            className={({ isActive }) => cn(
              "group relative flex items-center py-3 px-3 my-1 font-medium rounded-lg transition-colors",
              {
                "bg-primary text-white": isActive,
                "text-foreground hover:bg-primary/10": !isActive,
                "justify-center": !expanded,
                "justify-start": expanded
              }
            )}
          >
            <div className="relative">
              {icon}
              {notifications && notifications > 0 && (
                <div className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-xs font-semibold text-white">
                  {notifications > 9 ? '9+' : notifications}
                </div>
              )}
            </div>
            {expanded && (
              <motion.span
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                className="ml-3 overflow-hidden whitespace-nowrap"
              >
                {label}
              </motion.span>
            )}
          </NavLink>
        </TooltipTrigger>
        {!expanded && <TooltipContent side="right">{label}</TooltipContent>}
      </Tooltip>
    </TooltipProvider>
  );
};

export const Sidebar: React.FC = () => {
  const [expanded, setExpanded] = useState(true);
  const { user, logout } = useAuth();
  
  const toggleSidebar = () => setExpanded(!expanded);
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  const navItems = [
    { to: '/', icon: <Home className="h-5 w-5" />, label: 'Feed' },
    { to: '/explore', icon: <Search className="h-5 w-5" />, label: 'Explore' },
    { to: '/notifications', icon: <Bell className="h-5 w-5" />, label: 'Notifications', notifications: 2 },
    { to: '/messages', icon: <Mail className="h-5 w-5" />, label: 'Messages', notifications: 5 },
    { to: '/bookmarks', icon: <BookmarkIcon className="h-5 w-5" />, label: 'Bookmarks' },
    { to: `/profile/${user?.username || ''}`, icon: <User className="h-5 w-5" />, label: 'Profile' },
    { to: '/settings', icon: <Settings className="h-5 w-5" />, label: 'Settings' },
  ];

  return (
    <div
      className={cn(
        "h-screen flex flex-col border-r border-border bg-card transition-all duration-300 sticky top-0",
        expanded ? "w-64" : "w-20"
      )}
    >
      <div className="p-4 flex items-center justify-between">
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              className="overflow-hidden"
            >
              <div className="text-2xl font-bold text-primary">Connect</div>
            </motion.div>
          )}
        </AnimatePresence>
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          className="hover:bg-primary/10"
        >
          {expanded ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          <span className="sr-only">Toggle sidebar</span>
        </Button>
      </div>

      <nav className="flex-1 px-3 py-2">
        {navItems.map((item) => (
          <NavItem
            key={item.to}
            to={item.to}
            icon={item.icon}
            label={item.label}
            expanded={expanded}
            notifications={item.notifications}
          />
        ))}
        
        <Button 
          variant="default" 
          className={cn(
            "w-full mt-6 bg-primary hover:bg-primary-dark", 
            !expanded && "aspect-square p-0"
          )}
        >
          {expanded ? (
            <span>New Post</span>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M12 5v14M5 12h14" />
            </svg>
          )}
        </Button>
      </nav>

      <div className={cn(
        "p-4 border-t border-border mt-auto flex",
        expanded ? "justify-between" : "justify-center"
      )}>
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center"
            >
              <Avatar className="h-10 w-10">
                <AvatarImage 
                  src={user?.avatar} 
                  alt={user?.name || 'User'} 
                />
                <AvatarFallback>
                  {user?.name ? getInitials(user.name) : 'U'}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium line-clamp-1">{user?.name || 'User'}</p>
                <p className="text-xs text-muted-foreground line-clamp-1">
                  @{user?.username || 'username'}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-x-1">
          <ThemeToggle />
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={logout}
                  className="hover:bg-destructive/10 hover:text-destructive"
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Logout</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  );
};