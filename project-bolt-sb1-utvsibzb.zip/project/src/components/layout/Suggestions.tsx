import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { User } from '@/types';
import { getSuggestedUsers, followUser } from '@/services/userService';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export const Suggestions: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [followingStatus, setFollowingStatus] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchSuggestedUsers = async () => {
      try {
        setLoading(true);
        const suggestedUsers = await getSuggestedUsers(5);
        setUsers(suggestedUsers);
        
        // Initialize following status
        const status: Record<string, boolean> = {};
        suggestedUsers.forEach(user => {
          status[user._id] = false;
        });
        setFollowingStatus(status);
      } catch (error) {
        console.error('Failed to fetch suggested users:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSuggestedUsers();
  }, []);

  const handleFollow = async (userId: string) => {
    try {
      await followUser(userId);
      setFollowingStatus(prev => ({
        ...prev,
        [userId]: true
      }));
      toast.success('User followed successfully!');
    } catch (error) {
      console.error('Failed to follow user:', error);
      toast.error('Failed to follow user. Please try again.');
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <Card className="sticky top-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Suggestions for you</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          Array(5).fill(0).map((_, index) => (
            <div key={index} className="flex items-center space-x-3">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="space-y-1 flex-1">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
              <Skeleton className="h-8 w-16" />
            </div>
          ))
        ) : (
          <>
            {users.length > 0 ? (
              users.map(user => (
                <div key={user._id} className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage 
                      src={user.avatar} 
                      alt={user.name} 
                    />
                    <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <Link 
                      to={`/profile/${user.username}`} 
                      className="font-medium text-sm hover:underline truncate block"
                    >
                      {user.name}
                    </Link>
                    <p className="text-xs text-muted-foreground truncate">
                      @{user.username}
                    </p>
                  </div>
                  <Button 
                    variant={followingStatus[user._id] ? "outline" : "secondary"}
                    size="sm"
                    onClick={() => !followingStatus[user._id] && handleFollow(user._id)}
                    disabled={followingStatus[user._id]}
                    className="whitespace-nowrap"
                  >
                    {followingStatus[user._id] ? 'Following' : 'Follow'}
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">
                No suggestions available at the moment
              </p>
            )}
            <Button variant="ghost" size="sm" className="w-full mt-2 text-primary">
              See all
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
};