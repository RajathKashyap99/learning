import { useState } from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { MoreHorizontal, MessageCircle, Heart, Repeat2, Share, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Post } from '@/types';
import { useAuth } from '@/context/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { likePost, unlikePost, deletePost } from '@/services/postService';
import { toast } from 'sonner';

interface PostCardProps {
  post: Post;
  onDelete?: (postId: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onDelete }) => {
  const { user } = useAuth();
  const [isLiked, setIsLiked] = useState(post.likes.includes(user?._id || ''));
  const [likesCount, setLikesCount] = useState(post.likes.length);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const isAuthor = user?._id === post.author._id;
  
  const handleLikeToggle = async () => {
    try {
      if (isLiked) {
        await unlikePost(post._id);
        setIsLiked(false);
        setLikesCount(prev => prev - 1);
      } else {
        await likePost(post._id);
        setIsLiked(true);
        setLikesCount(prev => prev + 1);
      }
    } catch (error) {
      toast.error('Failed to update like status');
    }
  };
  
  const handleDeletePost = async () => {
    try {
      await deletePost(post._id);
      toast.success('Post deleted successfully');
      if (onDelete) {
        onDelete(post._id);
      }
    } catch (error) {
      toast.error('Failed to delete post');
    } finally {
      setIsDeleteDialogOpen(false);
    }
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-card rounded-lg shadow-sm border border-border mb-4 overflow-hidden"
    >
      <div className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex space-x-3">
            <Link to={`/profile/${post.author.username}`}>
              <Avatar>
                <AvatarImage 
                  src={post.author.avatar} 
                  alt={post.author.name} 
                />
                <AvatarFallback>{getInitials(post.author.name)}</AvatarFallback>
              </Avatar>
            </Link>
            <div>
              <Link 
                to={`/profile/${post.author.username}`}
                className="font-medium hover:underline"
              >
                {post.author.name}
              </Link>
              <div className="flex items-center space-x-1 text-muted-foreground text-sm">
                <Link 
                  to={`/profile/${post.author.username}`}
                  className="hover:underline"
                >
                  @{post.author.username}
                </Link>
                <span>·</span>
                <Link 
                  to={`/post/${post._id}`}
                  className="hover:underline"
                >
                  {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                </Link>
              </div>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">More options</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {isAuthor && (
                <>
                  <DropdownMenuItem 
                    className="text-destructive focus:text-destructive"
                    onClick={() => setIsDeleteDialogOpen(true)}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                </>
              )}
              <DropdownMenuItem>
                <Share className="mr-2 h-4 w-4" />
                Share
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="mb-3">
          <p className="whitespace-pre-line">{post.text}</p>
        </div>
        
        {post.images && post.images.length > 0 && (
          <div className={`mb-3 grid gap-2 ${post.images.length > 1 ? 'grid-cols-2' : 'grid-cols-1'}`}>
            {post.images.map((image, index) => (
              <div key={index} className="overflow-hidden rounded-lg">
                <AspectRatio ratio={16 / 9}>
                  <img 
                    src={image} 
                    alt={`Post content ${index + 1}`} 
                    className="object-cover w-full h-full"
                  />
                </AspectRatio>
              </div>
            ))}
          </div>
        )}
        
        <Separator className="my-3" />
        
        <div className="flex justify-between">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-muted-foreground hover:text-primary hover:bg-primary/10"
            as={Link}
            to={`/post/${post._id}`}
          >
            <MessageCircle className="mr-1 h-4 w-4" />
            <span>{post.commentsCount}</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className={`${isLiked ? 'text-destructive hover:text-destructive' : 'text-muted-foreground hover:text-destructive'} hover:bg-destructive/10`}
            onClick={handleLikeToggle}
          >
            <Heart className={`mr-1 h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
            <span>{likesCount}</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-muted-foreground hover:text-primary hover:bg-primary/10"
          >
            <Repeat2 className="mr-1 h-4 w-4" />
            <span>Repost</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-muted-foreground hover:text-primary hover:bg-primary/10"
          >
            <Share className="mr-1 h-4 w-4" />
            <span>Share</span>
          </Button>
        </div>
      </div>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your post.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeletePost}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
};