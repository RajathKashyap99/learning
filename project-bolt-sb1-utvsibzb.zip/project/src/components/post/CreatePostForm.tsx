import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Image as ImageIcon, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/context/AuthContext';
import { createPost } from '@/services/postService';
import { toast } from 'sonner';

interface CreatePostFormProps {
  onPostCreated: () => void;
}

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

const createPostSchema = z.object({
  text: z.string().min(1, 'Post cannot be empty').max(500, 'Post cannot exceed 500 characters'),
});

type FormValues = z.infer<typeof createPostSchema>;

export const CreatePostForm: React.FC<CreatePostFormProps> = ({ onPostCreated }) => {
  const { user } = useAuth();
  const [images, setImages] = useState<File[]>([]);
  const [imagesPreviews, setImagesPreviews] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(createPostSchema),
    defaultValues: {
      text: '',
    },
  });
  
  const { register, handleSubmit, reset, formState: { errors } } = form;
  
  const onDrop = (acceptedFiles: File[]) => {
    // Add only valid files
    const validFiles = acceptedFiles.filter(
      file => file.size <= MAX_FILE_SIZE && ACCEPTED_IMAGE_TYPES.includes(file.type)
    );
    
    if (validFiles.length !== acceptedFiles.length) {
      toast.error('Some files were rejected. Images must be less than 5MB and in JPEG, PNG, or WebP format.');
    }
    
    if (images.length + validFiles.length > 4) {
      toast.error('Maximum 4 images allowed');
      return;
    }
    
    // Generate previews for valid files
    const newPreviews = validFiles.map(file => URL.createObjectURL(file));
    
    setImages(prev => [...prev, ...validFiles]);
    setImagesPreviews(prev => [...prev, ...newPreviews]);
  };
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ACCEPTED_IMAGE_TYPES,
    },
    maxSize: MAX_FILE_SIZE,
    maxFiles: 4,
  });
  
  const removeImage = (index: number) => {
    // Revoke object URL to avoid memory leaks
    URL.revokeObjectURL(imagesPreviews[index]);
    
    setImages(prev => prev.filter((_, i) => i !== index));
    setImagesPreviews(prev => prev.filter((_, i) => i !== index));
  };
  
  const onSubmit = async (data: FormValues) => {
    try {
      setIsSubmitting(true);
      await createPost({
        text: data.text,
        images: images.length > 0 ? images : undefined,
      });
      
      // Clean up all image previews
      imagesPreviews.forEach(url => URL.revokeObjectURL(url));
      
      reset();
      setImages([]);
      setImagesPreviews([]);
      onPostCreated();
      toast.success('Post created successfully!');
    } catch (error) {
      toast.error('Failed to create post. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getInitials = (name: string = 'User') => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="flex gap-3">
            <Avatar>
              <AvatarImage 
                src={user?.avatar} 
                alt={user?.name || 'User'} 
              />
              <AvatarFallback>
                {user?.name ? getInitials(user.name) : 'U'}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <Textarea
                placeholder="What's happening?"
                className="resize-none border-none focus-visible:ring-0 p-0 shadow-none h-auto min-h-[80px]"
                {...register('text')}
              />
              
              {errors.text && (
                <p className="text-destructive text-sm mt-1">{errors.text.message}</p>
              )}
              
              <AnimatePresence>
                {imagesPreviews.length > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className={`grid gap-2 mt-3 ${
                      imagesPreviews.length > 1 ? 'grid-cols-2' : 'grid-cols-1'
                    }`}
                  >
                    {imagesPreviews.map((preview, index) => (
                      <div key={index} className="relative rounded-lg overflow-hidden">
                        <img 
                          src={preview} 
                          alt={`Preview ${index}`}
                          className="w-full h-48 object-cover" 
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 h-6 w-6 opacity-90"
                          onClick={() => removeImage(index)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
              
              <div className="flex justify-between items-center mt-4">
                <div className="flex gap-2">
                  <div {...getRootProps()}>
                    <input {...getInputProps()} />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="text-primary hover:bg-primary/10 rounded-full"
                      disabled={images.length >= 4}
                    >
                      <ImageIcon className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="bg-primary hover:bg-primary-dark rounded-full px-4"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    'Post'
                  )}
                </Button>
              </div>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};