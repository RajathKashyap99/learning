import express from 'express';
import {
  getCurrentUser,
  getUserProfile,
  updateProfile,
  uploadAvatar,
  uploadCoverImage,
  followUser,
  unfollowUser,
  getFollowers,
  getFollowing,
  searchUsers,
  getSuggestedUsers,
} from '../controllers/userController.js';
import { protect } from '../middleware/auth.js';
import { uploadAvatar as uploadAvatarMiddleware, uploadCoverImage as uploadCoverImageMiddleware } from '../middleware/upload.js';

const router = express.Router();

// Apply auth middleware to all routes
router.use(protect);

// Current user routes
router.get('/me', getCurrentUser);

// Profile routes
router.get('/profile/:username', getUserProfile);
router.put('/profile', updateProfile);
router.post('/avatar', uploadAvatarMiddleware, uploadAvatar);
router.post('/cover-image', uploadCoverImageMiddleware, uploadCoverImage);

// Follow routes
router.post('/:id/follow', followUser);
router.delete('/:id/follow', unfollowUser);
router.get('/:id/followers', getFollowers);
router.get('/:id/following', getFollowing);

// Search routes
router.get('/search', searchUsers);
router.get('/suggested', getSuggestedUsers);

export default router;