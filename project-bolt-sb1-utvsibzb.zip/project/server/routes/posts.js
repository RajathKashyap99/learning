import express from 'express';
import {
  createPost,
  getPosts,
  getUserPosts,
  getPost,
  updatePost,
  deletePost,
  likePost,
  unlikePost,
  getPostComments,
  createComment,
  deleteComment,
} from '../controllers/postController.js';
import { protect } from '../middleware/auth.js';
import { uploadImages } from '../middleware/upload.js';

const router = express.Router();

// Apply auth middleware to all routes
router.use(protect);

// Post routes
router.post('/', uploadImages, createPost);
router.get('/', getPosts);
router.get('/user/:userId', getUserPosts);
router.get('/:id', getPost);
router.put('/:id', updatePost);
router.delete('/:id', deletePost);

// Like routes
router.post('/:id/like', likePost);
router.delete('/:id/like', unlikePost);

// Comment routes
router.get('/:id/comments', getPostComments);
router.post('/:id/comments', createComment);
router.delete('/:postId/comments/:commentId', deleteComment);

export default router;