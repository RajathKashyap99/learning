import User from '../models/User.js';
import Post from '../models/Post.js';

// @desc    Get current user
// @route   GET /api/users/me
// @access  Private
export const getCurrentUser = async (req, res, next) => {
  try {
    const user = req.user;
    
    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// @desc    Get user profile by username
// @route   GET /api/users/profile/:username
// @access  Private
export const getUserProfile = async (req, res, next) => {
  try {
    const { username } = req.params;

    // Find user
    const user = await User.findOne({ username });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Get posts count
    const postsCount = await Post.countDocuments({ author: user._id });

    // Create user profile object with posts count
    const userProfile = {
      ...user.toObject(),
      postsCount,
    };

    res.status(200).json(userProfile);
  } catch (error) {
    next(error);
  }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
export const updateProfile = async (req, res, next) => {
  try {
    const { name, bio, location, website } = req.body;
    const userId = req.user._id;

    // Find user
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Update fields
    if (name) user.name = name;
    if (bio !== undefined) user.bio = bio;
    if (location !== undefined) user.location = location;
    if (website !== undefined) user.website = website;

    // Save user
    await user.save();

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// @desc    Upload user avatar
// @route   POST /api/users/avatar
// @access  Private
export const uploadAvatar = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an image',
      });
    }

    const userId = req.user._id;
    const avatarUrl = `/uploads/${req.file.filename}`;

    // Find user and update avatar
    const user = await User.findByIdAndUpdate(
      userId,
      { avatar: avatarUrl },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// @desc    Upload user cover image
// @route   POST /api/users/cover-image
// @access  Private
export const uploadCoverImage = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an image',
      });
    }

    const userId = req.user._id;
    const coverImageUrl = `/uploads/${req.file.filename}`;

    // Find user and update cover image
    const user = await User.findByIdAndUpdate(
      userId,
      { coverImage: coverImageUrl },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// @desc    Follow user
// @route   POST /api/users/:id/follow
// @access  Private
export const followUser = async (req, res, next) => {
  try {
    const userToFollowId = req.params.id;
    const userId = req.user._id;

    // Check if user is trying to follow themselves
    if (userToFollowId === userId.toString()) {
      return res.status(400).json({
        success: false,
        message: 'You cannot follow yourself',
      });
    }

    // Find user to follow
    const userToFollow = await User.findById(userToFollowId);

    if (!userToFollow) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if already following
    if (userToFollow.followers.includes(userId)) {
      return res.status(400).json({
        success: false,
        message: 'You are already following this user',
      });
    }

    // Update followers and following arrays
    await User.findByIdAndUpdate(userToFollowId, {
      $push: { followers: userId },
    });

    await User.findByIdAndUpdate(userId, {
      $push: { following: userToFollowId },
    });

    res.status(200).json({
      success: true,
      message: `You are now following ${userToFollow.username}`,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Unfollow user
// @route   DELETE /api/users/:id/follow
// @access  Private
export const unfollowUser = async (req, res, next) => {
  try {
    const userToUnfollowId = req.params.id;
    const userId = req.user._id;

    // Check if user is trying to unfollow themselves
    if (userToUnfollowId === userId.toString()) {
      return res.status(400).json({
        success: false,
        message: 'You cannot unfollow yourself',
      });
    }

    // Find user to unfollow
    const userToUnfollow = await User.findById(userToUnfollowId);

    if (!userToUnfollow) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if actually following
    if (!userToUnfollow.followers.includes(userId)) {
      return res.status(400).json({
        success: false,
        message: 'You are not following this user',
      });
    }

    // Update followers and following arrays
    await User.findByIdAndUpdate(userToUnfollowId, {
      $pull: { followers: userId },
    });

    await User.findByIdAndUpdate(userId, {
      $pull: { following: userToUnfollowId },
    });

    res.status(200).json({
      success: true,
      message: `You have unfollowed ${userToUnfollow.username}`,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get followers
// @route   GET /api/users/:id/followers
// @access  Private
export const getFollowers = async (req, res, next) => {
  try {
    const userId = req.params.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Find user
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Get total count
    const total = user.followers.length;

    // Get followers with pagination
    const followers = await User.find({ _id: { $in: user.followers } })
      .sort({ name: 1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      data: followers,
      pagination: {
        total,
        page,
        limit,
        hasMore: skip + followers.length < total,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get following
// @route   GET /api/users/:id/following
// @access  Private
export const getFollowing = async (req, res, next) => {
  try {
    const userId = req.params.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Find user
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Get total count
    const total = user.following.length;

    // Get following with pagination
    const following = await User.find({ _id: { $in: user.following } })
      .sort({ name: 1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      data: following,
      pagination: {
        total,
        page,
        limit,
        hasMore: skip + following.length < total,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Search users
// @route   GET /api/users/search
// @access  Private
export const searchUsers = async (req, res, next) => {
  try {
    const { q } = req.query;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a search query',
      });
    }

    // Create search regex
    const searchRegex = new RegExp(q, 'i');

    // Find users based on name or username
    const query = {
      $or: [{ name: searchRegex }, { username: searchRegex }],
    };

    // Get total count
    const total = await User.countDocuments(query);

    // Get users with pagination
    const users = await User.find(query)
      .sort({ name: 1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      data: users,
      pagination: {
        total,
        page,
        limit,
        hasMore: skip + users.length < total,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get suggested users
// @route   GET /api/users/suggested
// @access  Private
export const getSuggestedUsers = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const limit = parseInt(req.query.limit) || 5;

    // Get user's following list
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Find users not followed by current user
    const suggestedUsers = await User.find({
      _id: { $ne: userId, $nin: user.following },
    })
      .sort({ followers: -1 }) // Sort by follower count
      .limit(limit);

    res.status(200).json(suggestedUsers);
  } catch (error) {
    next(error);
  }
};