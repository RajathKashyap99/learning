import Post from '../models/Post.js';
import Comment from '../models/Comment.js';

// @desc    Create post
// @route   POST /api/posts
// @access  Private
export const createPost = async (req, res, next) => {
  try {
    const { text } = req.body;
    const userId = req.user._id;

    // Handle image uploads
    const images = req.files ? req.files.map(file => `/uploads/${file.filename}`) : [];

    // Create post
    const post = await Post.create({
      text,
      author: userId,
      images,
    });

    // Populate author details
    await post.populate('author');

    res.status(201).json(post);
  } catch (error) {
    next(error);
  }
};

// @desc    Get all posts (feed)
// @route   GET /api/posts
// @access  Private
export const getPosts = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Get total count
    const total = await Post.countDocuments();

    // Find posts with pagination and sorted by latest
    const posts = await Post.find()
      .populate('author')
      .populate('commentsCount')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      data: posts,
      pagination: {
        total,
        page,
        limit,
        hasMore: skip + posts.length < total,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user posts
// @route   GET /api/posts/user/:userId
// @access  Private
export const getUserPosts = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Get total count
    const total = await Post.countDocuments({ author: userId });

    // Find user posts with pagination and sorted by latest
    const posts = await Post.find({ author: userId })
      .populate('author')
      .populate('commentsCount')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      data: posts,
      pagination: {
        total,
        page,
        limit,
        hasMore: skip + posts.length < total,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single post
// @route   GET /api/posts/:id
// @access  Private
export const getPost = async (req, res, next) => {
  try {
    const { id } = req.params;

    // Find post
    const post = await Post.findById(id)
      .populate('author')
      .populate('commentsCount');

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    res.status(200).json(post);
  } catch (error) {
    next(error);
  }
};

// @desc    Update post
// @route   PUT /api/posts/:id
// @access  Private
export const updatePost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { text } = req.body;
    const userId = req.user._id;

    // Find post
    const post = await Post.findById(id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    // Check if user is the author
    if (post.author.toString() !== userId.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this post',
      });
    }

    // Update post
    post.text = text;
    await post.save();

    // Populate author details
    await post.populate('author');
    await post.populate('commentsCount');

    res.status(200).json(post);
  } catch (error) {
    next(error);
  }
};

// @desc    Delete post
// @route   DELETE /api/posts/:id
// @access  Private
export const deletePost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    // Find post
    const post = await Post.findById(id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    // Check if user is the author
    if (post.author.toString() !== userId.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this post',
      });
    }

    // Delete all comments associated with the post
    await Comment.deleteMany({ post: id });

    // Delete post
    await post.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Post deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Like post
// @route   POST /api/posts/:id/like
// @access  Private
export const likePost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    // Find post
    const post = await Post.findById(id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    // Check if post is already liked
    if (post.likes.includes(userId)) {
      return res.status(400).json({
        success: false,
        message: 'Post already liked',
      });
    }

    // Add like
    post.likes.push(userId);
    await post.save();

    // Populate author details
    await post.populate('author');
    await post.populate('commentsCount');

    res.status(200).json(post);
  } catch (error) {
    next(error);
  }
};

// @desc    Unlike post
// @route   DELETE /api/posts/:id/like
// @access  Private
export const unlikePost = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    // Find post
    const post = await Post.findById(id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    // Check if post is liked
    if (!post.likes.includes(userId)) {
      return res.status(400).json({
        success: false,
        message: 'Post not liked yet',
      });
    }

    // Remove like
    post.likes = post.likes.filter(id => id.toString() !== userId.toString());
    await post.save();

    // Populate author details
    await post.populate('author');
    await post.populate('commentsCount');

    res.status(200).json(post);
  } catch (error) {
    next(error);
  }
};

// @desc    Get post comments
// @route   GET /api/posts/:id/comments
// @access  Private
export const getPostComments = async (req, res, next) => {
  try {
    const { id } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Check if post exists
    const postExists = await Post.exists({ _id: id });

    if (!postExists) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    // Get total count
    const total = await Comment.countDocuments({ post: id });

    // Find comments with pagination and sorted by latest
    const comments = await Comment.find({ post: id })
      .populate('author')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      data: comments,
      pagination: {
        total,
        page,
        limit,
        hasMore: skip + comments.length < total,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create comment
// @route   POST /api/posts/:id/comments
// @access  Private
export const createComment = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { text } = req.body;
    const userId = req.user._id;

    // Check if post exists
    const post = await Post.findById(id);

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found',
      });
    }

    // Create comment
    const comment = await Comment.create({
      text,
      post: id,
      author: userId,
    });

    // Populate author details
    await comment.populate('author');

    res.status(201).json(comment);
  } catch (error) {
    next(error);
  }
};

// @desc    Delete comment
// @route   DELETE /api/posts/:postId/comments/:commentId
// @access  Private
export const deleteComment = async (req, res, next) => {
  try {
    const { postId, commentId } = req.params;
    const userId = req.user._id;

    // Find comment
    const comment = await Comment.findOne({
      _id: commentId,
      post: postId,
    });

    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Comment not found',
      });
    }

    // Check if user is the author
    if (comment.author.toString() !== userId.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this comment',
      });
    }

    // Delete comment
    await comment.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Comment deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};